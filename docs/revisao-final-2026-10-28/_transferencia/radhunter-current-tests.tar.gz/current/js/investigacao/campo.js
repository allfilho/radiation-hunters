// Cena comum: herda mapa, personagem, colisões, câmera e controles do jogo.
import {GameScene} from '../scenes/GameScene.js';
import {CONFIG} from '../data/config.js';
import {GameState} from '../estado.js';
import {currentLang} from '../i18n/index.js';
import {ui} from '../ui.js';
import {ESCALA_SPRITE} from '../render/personagem.js';
import {registrarNpcsHospital} from '../render/npcs-hospital.js';
import {mapaDeDistancias} from '../academia/objetivo.js';
import {investigacaoPorId} from './index.js';
import {abrirTreino,treinoFeito,treinoDaArea} from './treinamento-seguranca.js';
const SEM_AVISO=new Set(['desk','computer','shelf','cabinet','sink','bookcase','waiting_seats','work_table','learning_board','school_mural','reception_desk','sample_tray','sample_drawer','fridge','loupe','balance','locker','eyewash','safety_shower','extinguisher','first_aid','biohazard']);
const NOMES={helena:'Helena',rita:'Rita',camila:'Camila',andre:'André',lucia:'Lúcia',lara:'Lara',caio:'Caio',dora:'Dora',ines:'Inês',bia:'Bia',otto:'Otto',nina:'Nina',davi:'Davi',lea:'Léa',teo:'Teo',iris:'Íris'};
export function missaoInvestigacao(id,lang){
 const inv=investigacaoPorId(id);if(!inv?.campo)throw Error('Investigação sem configuração de campo: '+id);
 const c=inv.campo;
 return {id:c.numero,investigacao:inv.id,titulo:inv[lang==='pt'?'pt':'en'].titulo,numSources:0,timeLimit:0,mapTheme:c.tema,mapCols:c.planta?.cols,mapRows:c.planta?.rows,hospitalAtivo:!!c.hospitalAtivo,geigerComoItem:true,allowedIsotopes:[],difficulty:'normal',investigacaoCampo:c};
}
export class InvestigacaoScene extends GameScene{
 init(data){
  super.init(data);
  this.definicao=investigacaoPorId(this.missionData.investigacao);this.campo=this.definicao.campo;
  this.pontosInvestigacao=[];this.pontosHospital=this.pontosInvestigacao; // compatibilidade com inspeções da investigação original
  this.hudInvestigacao=null;
  this.encontros.iniciar=()=>{};this.encontros.checar=()=>{};
 }
 placeSources(){}
 updateGeiger(){}
 toggleGeiger(){}
 setShield(){}
 verificarAssistencia(){}
 dicaDisponivel(){return false;}
 create(){
  super.create();registrarNpcsHospital(this);
  this.temGeiger=false;GameState.temGeiger=false;this.geigerDevice.setVisible(false);
  const T=CONFIG.TILE_SIZE,usadas=[],candidatas=this.posicoesDoJogador().filter(p=>p.x%1===.5&&p.y%1===.5);
  if(this.campo.locais.length!==this.definicao.cenas.length)throw Error('Cada cena precisa de um ponto de campo');
  for(const local of this.campo.locais){
   const p=candidatas.filter(q=>usadas.every(u=>Math.hypot(q.x-u.x,q.y-u.y)>1.4)).sort((a,b)=>Math.hypot(a.x-local.x,a.y-local.y)-Math.hypot(b.x-local.x,b.y-local.y))[0];
   if(!p)throw Error('Ponto de investigação não alcançável: '+local.id);
   usadas.push(p);const c=this.add.container(p.x*T,p.y*T).setDepth(6),halo=this.add.circle(0,0,16,0xffd45a,.15).setStrokeStyle(2,0xffd45a,.85);c.add(halo);
   if(local.npc)c.add(this.add.image(0,4,'hospital_npc_'+local.npc).setScale(ESCALA_SPRITE).setOrigin(.5,.64));
   else{
    const g=this.add.graphics();g.lineStyle(2,0x80cbd5);g.fillStyle(0x294754);g.fillRoundedRect(-12,-11,24,22,3);g.strokeRoundedRect(-12,-11,24,22,3);
    if(local.icone==='frasco'){g.fillStyle(0xb9dfd4);g.fillRect(-5,-5,10,12);g.fillStyle(0x708d9e);g.fillRect(-4,-8,8,4);}
    else if(local.icone==='detector'){g.fillStyle(0x91c2c7);g.fillRect(-8,-7,16,14);g.lineStyle(1,0xe4efe0);g.lineBetween(0,-5,0,5);for(let j=-3;j<=3;j+=3)g.lineBetween(-5,j,5,j);}
    else{g.fillStyle(0xf1e6c8);g.fillRect(-8,-7,16,14);g.lineStyle(2,0x578c91);g.lineBetween(-5,-3,5,-3);g.lineBetween(-5,2,4,2);}c.add(g);
   }
   const nome=this.add.text(0,-30,local.npc?NOMES[local.npc]:local.curto?.[currentLang]||local[currentLang],{fontSize:'11px',fontFamily:'Orbitron',color:'#f6f6e9',backgroundColor:'#182a36',padding:{x:3,y:2}}).setOrigin(.5);
   c.add(nome);c.setSize(40,55).setInteractive({useHandCursor:true});const ponto={...local,x:p.x,y:p.y,obj:c,halo,nome};this.pontosInvestigacao.push(ponto);c.on('pointerdown',()=>this.interagirInvestigacao(ponto));
  }
  this.instrutores=[];
  for(const ins of this.campo.instrutores||[]){
   const p=candidatas.filter(q=>usadas.every(u=>Math.hypot(q.x-u.x,q.y-u.y)>1.4)).sort((a,b)=>Math.hypot(a.x-ins.x,a.y-ins.y)-Math.hypot(b.x-ins.x,b.y-ins.y))[0];
   if(!p)throw Error('Instrutor sem posição alcançável: '+ins.id);
   usadas.push(p);const c=this.add.container(p.x*T,p.y*T).setDepth(6),halo=this.add.circle(0,0,16,0x63d8ba,.12).setStrokeStyle(2,0x63d8ba,.8);
   c.add(halo);c.add(this.add.image(0,4,'hospital_npc_'+ins.npc).setScale(ESCALA_SPRITE).setOrigin(.5,.64));
   const nome=this.add.text(0,-30,NOMES[ins.npc]+' · '+(currentLang==='pt'?'segurança':'safety'),{fontSize:'11px',fontFamily:'Orbitron',color:'#f6f6e9',backgroundColor:'#1d4a43',padding:{x:3,y:2}}).setOrigin(.5);
   c.add(nome);c.setSize(40,55).setInteractive({useHandCursor:true});const item={...ins,x:p.x,y:p.y,obj:c,halo,nome};this.instrutores.push(item);c.on('pointerdown',()=>this.conversarInstrutor(item));
  }
  const tela=document.getElementById('game-screen');tela.classList.add('investigacao-campo');if(this.definicao.id==='hospital-imagem')tela.classList.add('hospital-investigacao');
  ui.mostrarBotoesGeiger(false);const interagir=document.getElementById('btn-identify');interagir.hidden=false;interagir.querySelector('.action-label').textContent=currentLang==='pt'?'Conversar':'Talk';interagir.title=currentLang==='pt'?'Conversar / observar (E ou Q)':'Talk / observe (E or Q)';
  const controles=document.querySelector('.hud-bottom-right');
  const leitura=document.createElement('button');leitura.id='inv-modo-leitura';leitura.className='action-btn';leitura.type='button';leitura.textContent=currentLang==='pt'?'Leitura':'Reading';
  leitura.addEventListener('click',()=>{ui.investigacao.emCampo=false;GameState.modalAberto=true;this.input.keyboard.enabled=false;ui.showScreen('investigacao');ui.investigacao.sessao.i=ui.investigacao.proximaCenaCampo();ui.investigacao.cena();});controles.append(leitura);
  const caderno=document.createElement('button');caderno.id='inv-caderno';caderno.className='action-btn';caderno.type='button';caderno.textContent=currentLang==='pt'?'Caderno':'Notebook';caderno.addEventListener('click',()=>{ui.investigacao.abrirCampo();ui.investigacao.fichaFinal();});controles.append(caderno);
  const limpar=()=>{leitura.remove();caderno.remove();if(!window.gameScene||window.gameScene===this)tela.classList.remove('investigacao-campo','hospital-investigacao');};this.events.once('shutdown',limpar);this.events.once('destroy',limpar);
  for(const sala of this.campo.salas)this.add.text(sala.x*T,sala.y*T,sala[currentLang],{fontSize:'11px',fontFamily:'Orbitron',color:'#dcf5ef',backgroundColor:'#203644',padding:{x:4,y:2}}).setDepth(4);
  const painel=this.campo.painel;
  if(painel)this.painelCampo=this.add.text(painel.x*T,painel.y*T,'',{fontSize:'9px',fontFamily:'Arial',color:'#203e4b',backgroundColor:'#f4ecd7',padding:{x:4,y:3},wordWrap:{width:90}}).setDepth(5);
  this.atualizarObjetivo();this.drawMinimap();
 }
 atualizarObjetivo(){
  if(!this.pontosInvestigacao?.length)return;
  const inv=ui.investigacao,n=inv.proximaCenaCampo(),total=this.pontosInvestigacao.length,p=this.pontosInvestigacao[n],sessao=inv.sessao,estado=n+'|'+currentLang+'|'+sessao.historico.length+'|'+(this.instrutores||[]).filter(i=>treinoFeito(i.id)).length;
  if(this.hudInvestigacao===estado)return;this.hudInvestigacao=estado;
  for(let i=0;i<total;i++){const q=this.pontosInvestigacao[i];q.obj.setVisible(n>=(q.visivelDe??0)&&n<=(q.visivelAte??total));q.halo.setStrokeStyle(i===n?2:1,i<n?0x63d8ba:i===n?0xffd45a:0x8aa5b2,.9);}
  const painel=this.campo.painel;
  if(this.painelCampo){
   const rascunho=sessao.mural&&!sessao.mural.revisado,decidiu=sessao.registro[painel.cenaDecisao],preparou=sessao.registro[painel.cenaCartoes];
   this.painelCampo.setText(rascunho?(currentLang==='pt'?'Rascunho\nRevisão necessária':'Draft\nRevision needed'):decidiu?painel.texto[currentLang]+'\n'+(currentLang==='pt'?'Mensagem revisada':'Message reviewed'):preparou?(currentLang==='pt'?'Painel preparado\nFalta revisar a mensagem':'Board prepared\nMessage needs review'):'');
  }
  ui.setProximo(`${this.campo.progresso[currentLang]} ${n}/${total}`,n===total?(currentLang==='pt'?'Investigação concluída · E para rever a ficha':'Investigation complete · E to review the record'):(currentLang==='pt'?'Próximo: ':'Next: ')+p[currentLang]);
  this.objAtual={id:this.definicao.id,alvo:p?{x:p.x,y:p.y}:null};const chave=p?.id||'fim';
  if(chave!==this.objChave){this.objChave=chave;this.mdObj=p?mapaDeDistancias(this.mapData.map,new Set(this.blockedTiles.map(b=>b.x+','+b.y)),p):null;}
  document.getElementById('sources-tracker').textContent=`${n}/${total} ${this.campo.progresso[currentLang].toLowerCase()}`+(this.instrutores?.length?` · ${currentLang==='pt'?'treinos':'training'} ${this.instrutores.filter(i=>treinoFeito(i.id)).length}/${this.instrutores.length}`:'');
 }
 desenharSeta(time){const antes=this.missionData.licoes;this.missionData.licoes=true;try{super.desenharSeta(time);}finally{this.missionData.licoes=antes;}}
 updateFurnitureInfo(){
  super.updateFurnitureInfo();if(!this.pontosInvestigacao?.length)return;
  const T=CONFIG.TILE_SIZE,movel=this.furniture.filter(f=>f.type[currentLang]).sort((a,b)=>Math.hypot(this.player.x-a.centerX,this.player.y-a.centerY)-Math.hypot(this.player.x-b.centerX,this.player.y-b.centerY))[0];
  if(movel&&Math.hypot(this.player.x-movel.centerX,this.player.y-movel.centerY)<70)this.furnitureInfoText.setText(movel.type[currentLang]);
  const p=this.maisPerto(),ins=this.instrutorPerto(),dp=p?Math.hypot(this.player.x/T-p.x,this.player.y/T-p.y):99,di=ins?Math.hypot(this.player.x/T-ins.x,this.player.y/T-ins.y):99;
  if(movel&&this.campo.planta&&this.instrutores?.length&&Math.hypot(this.player.x-movel.centerX,this.player.y-movel.centerY)<70&&!SEM_AVISO.has(movel.type.id)){
   const tr=treinoDaArea(this.campo.planta,Math.floor(movel.centerX/T),Math.floor(movel.centerY/T));
   if(tr&&!treinoFeito(tr.id))this.furnitureInfoText.setText(movel.type[currentLang]+(currentLang==='pt'?' · ⚠ treino de segurança pendente ('+NOMES[tr.npc]+')':' · ⚠ safety training pending ('+NOMES[tr.npc]+')'));
  }
  if(di<2&&di<dp)this.furnitureInfoText.setText(NOMES[ins.npc]+' · '+(currentLang==='pt'?'treino de segurança':'safety training')+(treinoFeito(ins.id)?' ✓':'')+' · E / Q');
  else if(dp<2)this.furnitureInfoText.setText(p[currentLang]+' · E / Q');
 }
 maisPerto(){const T=CONFIG.TILE_SIZE;return this.pontosInvestigacao.filter(p=>p.obj.visible).sort((a,b)=>Math.hypot(this.player.x/T-a.x,this.player.y/T-a.y)-Math.hypot(this.player.x/T-b.x,this.player.y/T-b.y))[0];}
 interagirInvestigacao(p=this.maisPerto()){
  if(this.bloqueado()||!p)return;
  if(Math.hypot(this.player.x/CONFIG.TILE_SIZE-p.x,this.player.y/CONFIG.TILE_SIZE-p.y)>2){ui.showNotification(currentLang==='pt'?'Aproxime-se para conversar ou observar.':'Move closer to talk or observe.','info');return;}
  const inv=ui.investigacao,n=inv.proximaCenaCampo(),i=this.pontosInvestigacao.indexOf(p);
  if(n>=this.pontosInvestigacao.length){inv.abrirCampo();inv.fichaFinal();return;}
  if(i>n){ui.showNotification((currentLang==='pt'?'Primeiro: ':'First: ')+this.pontosInvestigacao[n][currentLang],'info');return;}
  inv.sessao.i=i;inv.abrirCampo();inv.cena();
 }
 interagirHospital(p){this.interagirInvestigacao(p);}
 instrutorPerto(){const T=CONFIG.TILE_SIZE;return (this.instrutores||[]).slice().sort((a,b)=>Math.hypot(this.player.x/T-a.x,this.player.y/T-a.y)-Math.hypot(this.player.x/T-b.x,this.player.y/T-b.y))[0];}
 conversarInstrutor(ins){
  if(this.bloqueado()||!ins)return;const T=CONFIG.TILE_SIZE;
  if(Math.hypot(this.player.x/T-ins.x,this.player.y/T-ins.y)>2){ui.showNotification(currentLang==='pt'?'Aproxime-se para conversar com o instrutor.':'Move closer to talk to the instructor.','info');return;}
  GameState.modalAberto=true;
  abrirTreino(ins,currentLang,(r)=>{GameState.modalAberto=false;if(r.concluido){this.hudInvestigacao=null;ui.showNotification((currentLang==='pt'?'Treino de segurança concluído · ':'Safety training complete · ')+ins.lab[currentLang],'success');this.atualizarObjetivo();}});
 }
 handleIdentify(){
  const T=CONFIG.TILE_SIZE,d=(o)=>o?Math.hypot(this.player.x/T-o.x,this.player.y/T-o.y):99,ins=this.instrutorPerto(),p=this.maisPerto();
  if(ins&&d(ins)<2&&(d(p)>=2||d(ins)<=d(p))){this.conversarInstrutor(ins);return;}
  this.interagirInvestigacao();
 }
 revisarLicao(){this.interagirInvestigacao();}
 drawMinimap(){super.drawMinimap();if(!this.minimapCtx||!this.pontosInvestigacao)return;const g=this.minimapCtx,k=this.mmEscala,n=ui.investigacao.proximaCenaCampo();(this.instrutores||[]).forEach(i=>{g.fillStyle=treinoFeito(i.id)?'#63d8ba':'#3fa18c';g.fillRect((i.x-.25)*k,(i.y-.25)*k,k*.5,k*.5);});this.pontosInvestigacao.forEach((p,i)=>{if(!p.obj.visible)return;g.fillStyle=i===n?'#ffd45a':'#8ab5c6';g.fillRect((p.x-.3)*k,(p.y-.3)*k,k*.6,k*.6);});}
 restartMission(){ui.abrirInvestigacao(this.definicao.id);}
}
