export const missao = {
        id: 8,
        titleKey: 'mission8Title',
        descKey: 'mission8Desc',
        storyKey: 'story8',
        difficulty: 'insane',
        numSources: 8,
        timeLimit: 360,
        mapTheme: 'nuclear',
        unlocked: false,
        // Fukushima - multiple isotopes, large area
        allowedIsotopes: ['I-131', 'Cs-137', 'Sr-90'],
        concentratedSources: true,
    };
