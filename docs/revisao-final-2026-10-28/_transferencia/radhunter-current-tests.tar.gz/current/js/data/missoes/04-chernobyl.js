export const missao = {
        id: 4,
        titleKey: 'mission4Title',
        descKey: 'mission4Desc',
        storyKey: 'story4',
        difficulty: 'hard',
        numSources: 5,
        timeLimit: 240,
        mapTheme: 'nuclear',
        unlocked: false,
        // Chernobyl: Reactor isotopes - SOURCES NEAR REACTOR ONLY
        allowedIsotopes: ['I-131', 'Cs-137', 'Sr-90'],
        concentratedSources: true, // Sources placed near reactor
    };
