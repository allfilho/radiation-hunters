export const missao = {
        id: 6,
        titleKey: 'mission6Title',
        descKey: 'mission6Desc',
        storyKey: 'story6',
        difficulty: 'normal',
        numSources: 4,
        timeLimit: 200,
        mapTheme: 'hospital',
        unlocked: false,
        // Therac-25 inspired - medical accelerator
        allowedIsotopes: ['Co-60', 'Cs-137'],
    };
