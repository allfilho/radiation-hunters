# Radiation Hunters — The Isotope Chronicles (v2.2 em melhoria)

Jogo educativo do Grupo de Cronologia (IFGW/Unicamp). Site estático (HTML + CSS +
JS puro, sem backend e sem bundler), publicado em radiationhunters.netlify.app e
embutido por iframe no LabCronoVirtualRPG.

## Estrutura de pastas

    apps/radhunter/
      current/   versão atual do jogo  <- é isto que se publica
        index.html, styles.css
        js/main.js            ponto de entrada (cabeçalho de autoria, inicialização, globais p/ testes)
        js/i18n/{en,pt,index}.js     textos e t()/setLang()/updateTexts()
        js/data/{config,isotopes,shields,moveis}.js e js/data/missoes/01..08-*.js + index.js
        js/estado.js          GameState
        js/util.js            randomRange, shuffleArray, distance, formatTime
        js/fisica/{geiger,poisson,linha-de-visao}.js   geiger.js = modelo físico puro (roda em Node)
        js/progresso.js       localStorage com saneamento, estrelas, Continue
        js/mapa/{gerador,temas}.js
        js/render/moveis.js   FurnitureRenderer (móveis)
        js/render/terreno.js  pintarTerreno: piso, paredes e acessórios pintados num canvas, com semente fixa
        js/encontros/{motor,aproveitamento}.js   encontros de aprendizado: motor puro (Node) e aproveitamento 55/20/25
        js/encontros/{gerenciador,ui-encontro,caderno}.js   pontos fixos e gatilho do Geiger, modal do encontro (DOM) e caderno de campo
        js/data/encontros/{conceitos,perguntas}.js   árvore de 21 nós e banco de 60 perguntas PT/EN com fonte
        js/audio.js, js/ui.js, js/scenes/GameScene.js
      archive/   versões anteriores (no máximo 5)
      tests/     suíte de testes (node:test + Chromium headless); sondas/ = auditoria inicial; ferramentas/ = comparação entre versões
      docs/      documentos de projeto (fatos-historicos-3e.md, geiger-projeto-3a.md, parametros-fisicos.json, calc-parametros-3a.py, encontros-5c.md, referencias-5c/)
      tools/     dividir-modulos.mjs (recorta o game.js em módulos) e verificar-fatiamento.mjs (audita o recorte)
      README.md  este arquivo (changelog corrido)
    apps/radhunter.zip   original recebido; NÃO mexer (há cópia em archive/)

Regra de versionamento: só a versão atual em `current/`, sempre com os mesmos nomes
de arquivo; versões anteriores em `archive/`, no máximo 5.

## Como testar localmente

    cd apps/radhunter/current && python3 -m http.server 8000
    # abrir http://localhost:8000
    # Desde a etapa 2 o jogo usa ES modules: abrir o index.html direto (file://) NÃO funciona;
    # é preciso um servidor local. No Netlify funciona normalmente.

Testes: `cd tests && npm install && npm test` (ver `tests/README.md`).
Sondas exploratórias da auditoria inicial: `tests/sondas/README.md`.

## Publicação (nada é publicado por mim)

A pasta a publicar passou a ser `apps/radhunter/current`. Se o site Netlify
`radiationhunters` estiver ligado a uma pasta ou a um deploy manual, o diretório
de publicação deve apontar para ela. Comando, quando você decidir:

    netlify deploy --dir=apps/radhunter/current --site=<ID-do-site> --prod

(o ID do site e o login são seus; não os tenho).

## Plano revisado (aguarda autorização a cada etapa)

| Etapa | Conteúdo | Modelo / esforço |
|---|---|---|
| 0 | Organização de pastas e README. **Feita em 13/10/2026.** | Haiku, baixo |
| 1 | **Feita em 13/10/2026.** Suíte de testes que trava o comportamento atual e registra os bugs conhecidos como falhas esperadas (`todo`). Ver `tests/README.md` | Sonnet, médio |
| 2 | **Feita em 13/10/2026.** Reestruturar em ES modules, sem mudar lógica (ver changelog). O Geiger ainda mora em `GameScene.measureRadiation`; o módulo `js/fisica/geiger.js` nasce na etapa 3b | Sonnet, médio |
| 3a | **Feita em 13/10/2026; D1 a D8 aprovadas por Arnaldo (D4: chumbo de 1 cm).** Projeto do Geiger: modelo físico simplificado, tabela de parâmetros com fonte citável, metas de jogabilidade. Ver `docs/geiger-projeto-3a.md` | Modelo maior, alto, com pesquisa (NIST XCOM/ESTAR/ASTAR, ENSDF) |
| 3b | **Feita em 14/10/2026.** Implementar o Geiger como função pura e testável em Node (sem Phaser): contagem Poisson, 1/d², atenuação exponencial, alcance finito para alfa e beta, eficiência por tipo. Testes estatísticos (variância = média, inclinação -2 em log-log, blindagem) | Sonnet, médio/alto |
| 3c | **Feita em 14/10/2026.** Interface do Geiger: janela de integração e cps coerentes, cliques como processo de Poisson, texto educativo alinhado ao modelo | Sonnet, médio |
| 3d | **Feita em 14/10/2026 (jogo concluível nas 8 missões, verificado no Chromium).** Bugs funcionais: **identificação de fonte em móvel 3x3 (Chernobyl e Fukushima não concluem)**, velocidade presa à taxa de quadros, Continue/salvamento, configurações, `timeLimit` (calibrar antes), modais empilhados, saída ao menu, localStorage | Sonnet, médio |
| 3e | **Feita em 14/10/2026, com pendências menores** (ver `docs/fatos-historicos-3e.md`). Meias-vidas, missões e fatos históricos conferidos em fonte primária (AIEA, NNDC) | Modelo maior, alto, com pesquisa |
| 4 | **Feita em 14/10/2026** (histórias reescritas, notas de campo, fontes no texto). **Storytelling:** melhorar as histórias reais (revisão contra fonte primária), mais informação durante as missões (contexto, curiosidades, fatos do acidente à medida que o jogador avança), textos fluentes que misturem realidade e narrativa | Modelo maior, alto, com pesquisa; Sonnet para a redação final |
| 5a | **Feita em 14/10/2026.** Terreno pintado com semente fixa, paredes por tema, acessórios de chão, zoom 1,25 | Sonnet, médio/alto |
| 5b | **Feita em 14/10/2026.** Sombras nos móveis, ícones nas paredes (placas, quadros, extintores, painéis, luzes de alarme), poças de luz, tom de cor e adereços por missão, vinheta | Sonnet, médio/alto |
| 5c | **Documento de design escrito em 14/10/2026 (`docs/encontros-5c.md`), aprovado pelo Arnaldo com as decisões da seção 11.** Encontros de aprendizado: Mito x Fato e perguntas de tema, árvore de conceitos com reforço, pontos de aprendizado, caderno de campo; banco inicial de 40 perguntas com fonte | Modelo maior, alto, com pesquisa |
| 5d | **Feita em 14/10/2026: 5d-1 (motor, dados, testes), 5d-2 (modal, gatilhos, caderno, aproveitamento), 5d-3 (conferência das perguntas nas fontes) e 5d-4 (revisão crítica e testes de robustez). Falta só a opcional 5e (cofre) e a releitura dos textos na etapa 6.** Implementar os encontros, o caderno de campo (fichas) e os testes (o robô das 8 missões deve continuar concluindo) | Sonnet, médio/alto |
| 6 | Acessibilidade (teclado, contraste, alvos de toque, movimento reduzido, projetor), toque no celular, idiomas e revisão dos textos | Sonnet, médio |
| 7 | Revisão final crítica | Modelo maior, alto |

### Direção de narrativa e encontros de aprendizado (definida com Arnaldo em 14/10/2026; implementada nas etapas 5d-1 e 5d-2; redação final das perguntas na 5d-3)

- **Narrativa principal:** o jogador é um Caçador de Radiação que recolhe as fontes radioativas espalhadas para guardá-las em segurança (como numa "cobrinha" que coleta itens, mas aqui o objetivo é a segurança, não o combate). O "inimigo" é o risco e a desinformação, não um monstro. Possível etapa de guarda segura no fim da missão (cofre blindado), ligada à blindagem e ao ALARA.
- **Encontros:** surpresas curtas e narrativas, de 2 a 3 por missão, em pontos **semeados por missão** (iguais para todos os alunos) ou ligados a gatilhos físicos (primeiro pico no Geiger, entrada em zona contaminada). **Não são aleatórios puros**, para não punir quem tem azar nem distorcer as estrelas em sala de aula.
- **Regras:** relógio pausado durante o encontro; o acerto rende **pontos bônus extras** (não mexe no tempo); erro só mostra a explicação, sem perda; tudo por teclado e toque; interruptor nas configurações para desligar.
- **Formato preferido:** ficha de aprendizado em duelo "Mito x Fato", com a fonte citada; o conteúdo só usa fatos já verificados (`docs/fatos-historicos-3e.md`) e física já testada. O que não tem fonte lida fica de fora.
- **Medir o ganho de aprendizado** com o jogo é um objetivo futuro, fora do escopo atual.

## Modelo do Geiger — proposta a validar (etapa 3a; nenhum valor é definitivo)

Princípios, a partir das suas indicações:

- Taxa esperada de uma fonte: `R = A · G(d) · T_ar(d) · T_blindagem`, mais o fundo.
- **Gama:** `G = 1/d²` (com uma distância mínima, para não divergir), atenuação
  no ar desprezível na escala do jogo e blindagem `exp(-μ·x)`, com μ dependente do
  material e da energia (Tc-99m, Cs-137 e Co-60 não podem ter o mesmo fator).
- **Beta:** também `1/d²`, mas com alcance finito no ar; blindagem pelo alcance do
  beta no material (alumínio e acrílico bloqueiam; chumbo também, com a ressalva
  da radiação de freamento).
- **Alfa:** não segue `1/d²` na prática, porque o ar a bloqueia em poucos
  centímetros. A taxa é aproximadamente constante até perto do alcance e cai
  rapidamente; qualquer folha a bloqueia. Na escala do jogo isso vira "só no
  contato".
- **Estatística:** o número de contagens na janela é Poisson de média
  `(R + fundo)·Δt`; os cliques sonoros também. Fonte fraca perto do fundo exige
  integrar por mais tempo, o que dá a dificuldade de busca que você descreveu.
- Parâmetros a conferir antes de usar: μ de cada blindagem por energia (NIST
  XCOM), alcance de beta e de alfa no ar e nos materiais (NIST ESTAR e ASTAR),
  energias de emissão e meias-vidas (ENSDF/NNDC; tabela do BIPM).

Decisões tomadas (Arnaldo, 13/10/2026):

1. **Escala didática, por sala.** Cada missão tem salas desenhadas em escala
   física; a conversão é `cmPorPixel` por tema/missão (a definir; ex.: 1 px = 1 cm
   daria um mapa de 24x16 tiles de 32 px = cerca de 7,7 m x 5,1 m). A distância
   fonte-detector passa a ser calculada em cm. A sonda (ponta do detector) terá
   posição própria à frente do jogador; o alcance da alfa (poucos cm) só é
   atingível trazendo a ponta até a fonte.
2. **Paredes de concreto atenuam a gama (exp(-mu x) pela espessura atravessada) e
   bloqueiam alfa e beta.** Em vez do teste de linha de visão sim/não, o raio
   fonte-sonda acumula a espessura de parede atravessada. Quanto a gama atravessa
   depende da energia e da espessura (a conferir em NIST XCOM / NCRP 147; Tc-99m
   de 140 keV deve ser bem mais barrado que Co-60).
3. **Cone = aceitação angular do detector, não emissão da fonte.** A fonte é
   isotrópica. A sonda GM tem janela fina, direcional para alfa e beta; para gama
   a resposta é pouco direcional. Proposta: função de aceitação `f(theta)`
   íngreme para alfa/beta e suave (com piso) para gama, parâmetros a conferir na
   ficha de uma sonda real. O cone visual do jogador fica separado do cone de
   aceitação do detector.
4. **Atividade constante durante a missão.** Aproximação válida. Fração decaída em
   um tempo t: `1 - 2^(-t/T1/2)`. Para o isótopo de meia-vida mais curta do jogo
   (Tc-99m, cerca de 6 h, valor a confirmar na ENSDF), uma missão de 6 min perde
   cerca de 1,1%; uma hora perderia cerca de 11%. Um teste automático verificará,
   para cada isótopo, que a perda no tempo máximo de missão fica abaixo de um
   limite declarado. A meia-vida continua entrando no jogo como informação
   (lambda = ln2/T1/2 nos cartões educativos), não como dinâmica.

Pendências derivadas: (a) faixa dinâmica (1/d2 entre 10 cm e 8 m cobre mais de
três ordens de grandeza; o mostrador precisa de escala logarítmica e o som vira a
pista principal); (b) espessura e material das paredes por tema; (c) mobiliário
como atenuador (adiado); (d) fontes dentro de blindagem/contêiner (adiado).

## Changelog corrido

### 2026-10-13 — Auditoria inicial (jogo não modificado)
- Pedido: ler tudo, abrir em Chromium headless, listar achados por prioridade,
  mapear dependências e apresentar plano.
- Resultado: lista de achados entregue no chat. Sondas em `tests/sondas/`.
- Achados principais: Continue inexistente; três configurações sem efeito;
  `timeLimit` ignorado; Esc empilha modais; localStorage bloqueado ou com tipo
  errado derruba a inicialização; Geiger com sinal determinístico (só o fundo é
  Poisson); queda gama linear em vez de 1/d²; sem controles de toque; sem espanhol.

### 2026-10-13 — Etapa 0: organização
- `game.js`, `index.html`, `styles.css` movidos para `current/` (conteúdo
  idêntico; conferido com `node --check`).
- Cópia do original em `archive/radhunter-original-2026-10-13.zip` (idêntica ao
  `apps/radhunter.zip`, que ficou onde estava).
- Criadas `tests/` e `tests/sondas/` com as quatro sondas de auditoria.
- Nenhuma linha de código do jogo foi alterada. Cabeçalho de autoria intacto.
- Nenhuma referência por caminho foi encontrada no README do portal, nos testes
  nem em `vlabmain`; o portal aponta para a URL do Netlify.

### 2026-10-13 — Decisões de projeto do Geiger
- Registradas as quatro decisões acima (escala, paredes, aceitação angular,
  atividade constante). Nenhum código alterado. Aguarda autorização para a etapa 1.

### 2026-10-13 — Etapa 1: testes que travam o comportamento atual
- Criada a suíte em `tests/` (50 testes): dados (i18n, isótopos, blindagens,
  missões), fluxo (menus, 8 missões, pausa, reinício, identificação, conclusão,
  progresso), robustez (localStorage) e Geiger (modelo atual por tipo, distância,
  blindagem, cone, fundo).
- Resultado: **33 passam, 17 são `todo` (falhas conhecidas), 0 falham**; três
  execuções iguais. Cinco mutações manuais em uma cópia do jogo foram todas detectadas.
- Duas falhas da primeira rodada eram do teste, não do jogo: `scene.resume()` e
  `scene.restart()` são assíncronos no Phaser. Corrigido esperando a cena ativa.
- Os 17 `todo` documentam: Continue inexistente, salvamento só no `beforeunload`,
  Esc empilhando modais, canvas não destruído ao sair, três configurações sem efeito,
  `timeLimit` ignorado, sem controles de toque, localStorage bloqueado ou com tipo
  errado, três textos que não seguem o idioma, e quatro itens de física (sinal Poisson,
  1/d², gama fora do cone, tabela de meias-vidas).
- O jogo (`current/`) não foi alterado: md5 conferido igual ao do início.
- Observação: a segunda gravação deste README (decisões do Geiger) não aparecia no
  disco quando conferi; regravado nesta etapa.

### 2026-10-13 — Etapa 2: divisão em ES modules (só mover código)
- `game.js` (5.604 linhas) virou 26 módulos em `current/js/`; `index.html` troca
  `<script src="game.js">` por `<script type="module" src="js/main.js">` (única
  mudança nele). `styles.css` intacto. Phaser continua fixado em 3.60.0 (CDN).
- O recorte foi **mecânico**: `tools/dividir-modulos.mjs` copia o texto de cada
  declaração do original sem redigitar, e calcula os `import` por análise de escopo
  (eslint-scope). Fim de linha CRLF preservado. Mapa de dependências: acíclico
  (UIManager e GameScene só se falam por `window.gameScene`, como antes).
- Único texto de lógica alterado (equivalente): um módulo importador não pode
  reatribuir `currentLang`; as duas atribuições viraram `setLang(...)` (em `ui.js`
  e `main.js`), e `setLang` mora em `js/i18n/index.js`. Cola nova: imports/exports,
  `i18n = { en, pt }`, `MISSIONS = [...]` montado dos 8 arquivos, e em `main.js` a
  exposição de globais (`GameState`, `ui`, `CONFIG`, ...) que a suíte de testes lê.
- O cabeçalho de autoria foi **movido sem alteração** para o topo de `js/main.js`.
  Peço sua confirmação desse novo endereço (ver Pendências abaixo).
- `game`, `pendingMission` e a substituição de `UIManager.prototype.startMission`
  continuam em `main.js`, como no original. Ficam para a etapa 3d.
- Modo estrito: módulos são sempre estritos; análise de escopo não achou atribuição
  a variável não declarada, e as 8 missões rodam sem erro no console.
- Verificação: (1) `tools/verificar-fatiamento.mjs`: 39 declarações do original
  presentes uma vez, byte a byte, e só 16 linhas novas (a cola declarada acima);
  (2) suíte inalterada: **33 passam, 17 todo, 0 falhas**, mesmo conjunto de
  resultados de antes, em 2 rodadas; (3) `tests/ferramentas/comparar-versoes.mjs`:
  com a mesma semente, mapa, móveis, fontes e 4 leituras do Geiger por fonte são
  **idênticos nas 8 missões**; (4) pixels do canvas iguais nas missões sem animação
  dependente do tempo; nas demais, a própria versão antiga difere dela mesma entre
  duas execuções, então a prova de pixels ali é inconclusiva (a prova é o item 1).
- Versão anterior arquivada em `archive/2026-10-13_pre-modulos/` (game.js,
  index.html, styles.css). `archive/` tem 2 itens (limite: 5).
- Nada publicado. Para publicar, o diretório continua sendo `apps/radhunter/current`
  (agora com a subpasta `js/`; o Netlify serve módulos sem configuração extra).

### 2026-10-13 — Etapa 3a: projeto do Geiger (só documentos; o jogo não mudou)

- Pedido: projeto do modelo do Geiger com parâmetros de fonte citável; novas etapas 4
  (storytelling) e 5 (gráficos, mapas, tileset com acessórios); acessibilidade e revisão final
  passam a 6 e 7.
- Criados `docs/geiger-projeto-3a.md`, `docs/parametros-fisicos.json` e `docs/calc-parametros-3a.py`.
- Verificado nesta etapa (NIST XCOM, tabelas LNHB, datasheet Ludlum 44-9): coeficientes de
  atenuação e densidades do chumbo, alumínio, concreto, PMMA e ar; meias-vidas e emissões de 11
  isótopos; alcance beta (Katz-Penfold, conferido com o P-32). Escolhas de jogo estão marcadas [H] e o
  que falta fonte, [P] (ASTAR/ESTAR, tempo morto, resposta angular, bremsstrahlung, buildup).
- Decisões a tomar: D1 (alfa por contato), D2 (50 cm por tile), D3 (gama fora do cone com piso
  de 0,3), D4 (espessuras das blindagens), D5 (parede de 30 cm de concreto), D6 (integração de 3 s), D7 (identificar pela superfície do móvel), D8 (não aplicar os `timeLimit` atuais como derrota).

### 2026-10-13 — Etapa 3a (complemento): verificação de jogabilidade por simulação

- Pedido: conferir se o modelo proposto é prático e jogável.
- Feito: `tests/simulacao/` (extrai os 8 mapas reais, 6 sorteios cada; robô-jogador; modelo atual e proposto; cobertura de áudio/gradiente). Resultados na seção 12 de `docs/geiger-projeto-3a.md`.
- Resultado: o modelo proposto não deixa nenhuma missão mais lenta que a atual (medianas de 124 a 283 s no robô) e é insensível aos parâmetros [H] (escala, parede, piso do gama, força das fontes). Fatores de força revisados: gama 0,3 x base a 1 m; beta 1,0 x base a 0,5 m. Janela de exibição de 3 s (D6).
- **Bug do jogo atual achado e confirmado no jogo real:** o móvel "Damaged Core" (3x3) sempre recebe fonte nas missões 4 e 8 e a fonte não pode ser identificada (menor distância alcançável 1,813 tile; limite 1,5). Nada foi corrigido ainda (3d); novo teste `todo` em `02-fluxo`. Nova decisão D7.
- Também registrado (3d): velocidade independente de `delta` (por leitura do código, não testado em 120/144 Hz); `timeLimit` declarado e não aplicado, com valores abaixo do p90 do robô em 4 de 6 missões (D8).
- Limite: o robô não é uma pessoa; a pergunta "é divertido?" exige teste com jogadores.
- O jogo (`current/`) não foi modificado.

### 2026-10-14 — Etapas 3b, 3c e 3d: Geiger novo, interface e bugs funcionais

- Pedido: "corrigir os bugs e fazer o que for necessário para que o jogo fique totalmente jogável e as
  missões concluíveis". Decisões D1 a D8 do projeto 3a tratadas como aprovadas.
- **Geiger (3b/3c).** `js/fisica/geiger.js` (puro, sem Phaser): taxa = fundo + soma por fonte de
  `S·G(d)·T_ar·T_blindagem·T_parede·f(θ)`; gama 1/d² com exp(-μx) (NIST XCOM, interpolação log-log);
  beta 1/d² com corte linear no alcance (Katz-Penfold) e parede bloqueando; alfa só por contato
  (superfície a ≤ 1 tile); contagens Poisson; média móvel de 3 s com incerteza √N/T; painel em escala
  logarítmica; cliques sonoros no ritmo da contagem. Blindagens agora têm material e espessura reais
  (Al 3 mm, acrílico 5 mm, chumbo **1 cm**; o 1 cm é escolha minha dentro da D4, marcada [H]). Paredes:
  30 cm de concreto; 50 cm por tile. Meias-vidas e energias entram em `isotopes.js` (LNHB/NIST do 3a).
- **Identificar (D7).** Distância medida da superfície do móvel (`IDENTIFY_DISTANCE` 1,0 e
  `OBSERVE_DISTANCE` 2,0 tiles, agora da superfície, não do centro): corrige o bug do "Damaged Core" 3x3
  que impedia concluir as missões 4 e 8.
- **Bugs corrigidos (3d):** velocidade independente da taxa de quadros; pausa só por sinalizador
  (`scene.pause/resume` eram assíncronos); Esc no DOM (fecha painéis, fecha identificação, retoma ou
  pausa; nunca empilha); movimento congelado com o modal de identificação aberto; erro de identificação
  não trava mais os botões (voltam após a dica; o isótopo errado fica riscado; a fonte continua
  selecionada); temporizadores da cena (`this.time.delayedCall`) no lugar de `setTimeout`; relógio
  conta só o tempo jogado (sem pausa nem tela final); conclusão congela a cena; **progresso e estrelas
  gravados ao concluir** (`js/progresso.js`); botão **Continuar** (última missão desbloqueada); sair ao
  menu e voltar após concluir **destroem o Phaser**; configurações (dicas, tremor, música) funcionam e
  são gravadas; **música ambiente** sintetizada (`audio.js`, sem arquivos); `localStorage` bloqueado ou
  com lixo não derruba mais (saneamento de missões, estrelas e configurações); `<html lang>` e títulos
  das blindagens acompanham o idioma; mensagens de conclusão em i18n; **controles de toque**
  (direcional e correr; aparecem em tela estreita ou sem mouse).
- **`timeLimit` (D8):** vira **meta de tempo**, não derrota. HUD mostra tempo / meta; 3 estrelas pedem
  precisão ≥ 80% dentro da meta; missões sem `timeLimit` usam 240 s [H]. Bônus de tempo = 2 pontos por
  segundo abaixo da meta.
- **Testes:** 78 testes, todos passam (ver `tests/README.md`). Os 18 `todo` viraram testes normais. Novo
  `06-jogabilidade`: um robô conclui **as 8 missões** no jogo real (Chromium), mais movimento por teclado,
  toque e pausa. Limite declarado: o robô se teletransporta entre posições alcançáveis (inundação sobre
  `isBlocked`); a descoberta por gradiente está em `tests/simulacao/`.
- Arquivado: nada novo (a versão anterior já estava em `archive/2026-10-13_pre-geiger/`, idêntica ao
  `current/` anterior; conferido com `diff -r`).
- Ainda aberto: textos que citam CPM (história 1) e "alcance alfa ~4 cm" não batem com o painel em cps
  e com o alcance didático de 1 tile (vão para a revisão de textos, etapas 3e/4); conferência ASTAR/ESTAR
  e Emax do Y-90 ([P] do 3a); resposta em 120/144 Hz só por leitura do código.

### 2026-10-14 — Etapas 3e e 4 (primeira rodada): fatos históricos e storytelling

- Pedido: "depois pode seguir com melhoria das histórias e do storytelling". Pesquisa em documentos oficiais
  (AIEA, CSN, Fórum Chernobyl/OMS, BASE, Parlamento da Índia/AERB); tabela completa em `docs/fatos-historicos-3e.md`.
- **Erros factuais das histórias originais corrigidos:** Zaragoza (foi um acelerador linear de elétrons, sem
  isótopo; a missão virou ficção declarada), Lia (três homens buscando lenha, não "caçadores"; recuperação em
  fev/2002 pela AIEA), Mayapuri (números "15 g" e "~60 TBq" não verificados: removidos; 16 canetas x 7
  pastilhas, 1 morte, 7 internados), Goiânia (relações entre personagens removidas; números da AIEA 1988),
  Fukushima ("150.000+" trocado por ~110.000 evacuados / ~165.000 deslocados; 30 a 40 anos de
  descomissionamento), Chernobyl (causa não afirmada; números do Fórum Chernobyl).
- **Cobalto-60 retirado das missões 4 e 8** (não é radionuclídeo principal desses acidentes). Muda o conjunto de
  isótopos sorteados nessas missões; o robô ainda conclui as 8.
- **Histórias reescritas** (en e pt): fato real, "lição", número, linha "NO JOGO" que separa realidade de
  simplificação, e linha de **Fonte**. Textos antigos com "CPM" e "alcance alfa ~4 cm" corrigidos (cps; alcance
  didático de 50 cm explicado). Removidas alegações não verificadas ("brilha azul", "80% dos procedimentos").
- **Notas de campo:** 4 por missão (32 por idioma), exibidas ao identificar a 1ª a 4ª fonte, no modal de
  identificação (chaves `fact<missão>_<n>`). O modal fica 8 a 9 s no acerto para dar tempo de ler.
- **História:** texto aparece mais rápido (12 ms por passo, 3 caracteres) e clicar no texto mostra tudo;
  rolagem própria e alinhamento à esquerda.
- Testes: 80 (todos passam). Novos: notas e fontes em todas as missões; ausência das alegações removidas;
  Co-60 fora de 4 e 8.
- **Não verificado em fonte primária ([S] ou [N] em `docs/fatos-historicos-3e.md`):** relatório AIEA de Lia
  (usei resumo da Wikipédia), número de pacientes e mortes de Zaragoza (fontes divergem: 11 a 15), atividade do
  Co-60 de Mayapuri, causa de Chernobyl, textos de época das Radium Girls.

### 2026-10-14 — Etapas 3e e 4, segunda rodada: pendências de fonte primária fechadas

- **Lia:** relatório da AIEA (2014) lido: moradores buscando lenha em 2/12/2001; ~1.300 TBq por fonte (1.480 TBq de projeto); ~1 Sv/h a 1 m; internação em 22/12 (Zugdidi); um paciente morreu em 13/05/2004; recuperação em 2-3/02/2002, contêiner com 25 cm de chumbo (o relatório cita também 27 cm: inconsistência interna).
- **Zaragoza:** AIEA (RPOP): 27 pacientes, 15 mortes pela sobredose e 2 com contribuição importante. Substitui o "mais de dez" anterior (a Wikipédia dá 11).
- **Chernobyl:** INSAG-7 (AIEA, 1992): experimento com a alimentação elétrica independente; causa principal = comportamento instável do reator, mudanças não aprovadas no teste e cultura de segurança deficiente. A história agora cita isso.
- **Radium Girls:** USTUR/WSU confirma Ra-228 (mesotório, 5,8 a) na tinta real e a proibição de afinar o pincel com a boca em 1929.
- **Mayapuri:** segue sem valor de atividade do Co-60 em nenhuma fonte lida (Parlamento, AERB/INIS, artigo médico 2013, Wikipédia); o jogo não cita valor. Divergências registradas (1968 x 1969; 7 internados x 8 expostos).
- Testes: 80, todos passam (sem mudança de contagem).

### 2026-10-14 — Etapa 5: terreno, paredes e acessórios (gráficos)

- Novo `js/render/terreno.js`: o piso, as paredes e os acessórios de chão de cada mapa são pintados **uma vez** num canvas (2x a resolução, 1.536 x 1.024 px) com gerador pseudoaleatório semeado pelo número da missão (mulberry32). Antes, `GameScene.drawMap` criava centenas de objetos do Phaser por mapa e usava `Math.random`, então o aspecto mudava a cada partida. Agora: mesma missão = mesmo aspecto, menos objetos na cena.
- Por tema: laboratório (vinil com juntas, paredes claras com faixa azul), ferro-velho (terra e cascalho; paredes de pneus, chapas, carcaças e tambores), hospital (linóleo xadrez gasto; tinta descascada e rodapé), fábrica (tábuas; tijolos), nuclear (lajes de concreto; concreto rachado com vergalhão; faixa de perigo em volta do reator), bunker/floresta (grama em três tons; árvores). Acessórios de chão (manchas, cabos, rachaduras, folhas, pedras, samambaias, entulho, marcas de pneu) são **só visuais**: não bloqueiam e não mexem na física (as fontes continuam dentro dos móveis).
- Paredes com face frontal em pseudo-3D e sombra de contato no piso; janelas pintadas no tile 3.
- Câmera com zoom 1,25 centrada no mapa (768 x 512 vira 960 x 640): some a faixa preta ao lado do mapa. O texto do móvel (scrollFactor 0) foi compensado para ficar em (20, 82) da tela e do mesmo tamanho. A colisão não mudou (tile 1 bloqueia; móveis bloqueiam).
- Testes: 83 (todos passam). Novo `07-graficos`: sem `Math.random(` em `drawMap` e `terreno.js`; mesma missão gera o mesmo canvas e missões diferentes geram canvas diferentes; toda parede bloqueia; zoom e posição do texto.
- **Pendente nesta etapa (próximas rodadas, se Arnaldo quiser):** sombras e mais acessórios nos móveis, cartazes e placas nas paredes, mini-mapa que cobre o canto superior direito do mapa agora que o zoom preenche a tela (avaliar na etapa 6), conferir escala visual dos móveis. Arquivo anterior em `archive/2026-10-14_pre-graficos/`.

### 2026-10-14 — Etapa 5b: sombras, itens nas paredes, luzes e identidade por missão

- `terreno.js` ganhou, além do terreno: (1) **ícones nas paredes** (laboratório: placa de radiação, quadro, grade de ventilação, extintor, relógio; hospital: cruz, mural, grade, corrimão; fábrica: tubo, manômetro, luminária; nuclear: triângulo de perigo, eletroduto, luz de alarme, painel de LEDs), todos sem texto para não depender do idioma; (2) **sombras suaves** sob cada móvel; (3) **poças de luz** no piso (laboratório, hospital, fábrica, nuclear); (4) **identidade por missão**: tom de cor próprio e adereços (fita de segurança na 1, lixo e fardos na 2 e na 7, serragem na 3, marcas de maca na 6, troncos e lenha caídos na 5, poças d'água na 8); (5) **vinheta** nas bordas.
- Tudo é só visual e feito em tempo de pintura, com a mesma semente da missão: não muda colisão, nem física, nem a posição das fontes. Os adereços são liberdade artística genérica, **não afirmam fatos históricos**.
- Testes: 83, todos passam. Arquivo anterior em `archive/2026-10-14_pre-graficos-5b/`; para respeitar o limite de 5, foi removido `archive/2026-10-13_pre-geiger/` (o `.zip` original e as demais versões permanecem).

### 2026-10-14 — Etapa 5c, pesquisa de fontes (`docs/referencias-5c/`)

- Pesquisa com a skill de referências para o banco de fichas "Mito x Fato" e para fatos dos acidentes: ~109 fichas brutas em `busca/` e a síntese em `resumao.md` (fatos prontos para ficha, divergências, lacunas, referências). Fontes oficiais priorizadas (AIEA, OMS, UNSCEAR, NRC, EPA, CDC, CNEN, ICRP, CSN, ATSDR, USTUR).
- Conferi 14 itens (13%) nas páginas originais: todos confirmados. Limite: leitura por WebFetch, sem os PDFs; trechos entre aspas precisam ser reabertos na fonte.
- **Achados que afetam o jogo (nada foi alterado ainda):** (1) o relatório da AIEA sobre Goiânia registra que o material "brilhava em azul no escuro" e atribui o brilho, com cautela, a fluorescência ou radiação Cherenkov: o "brilho azul" que retirei na etapa 4 pode voltar com essa ressalva; (2) fundo natural mundial: 2,4 mSv/ano (OMS 2020, UNSCEAR FAQ) x ~3,0 mSv (relatório mais recente do UNSCEAR, via ARPANSA 2026); (3) Mayapuri: atividade do Co-60 segue não encontrada em 10 fontes, e o ano de compra diverge (1967 a 1970); (4) Chernobyl e liquidators: números diferem entre Fórum 2005, UNSCEAR 2008 e 2018.
- **Pendente:** documento de design dos encontros (5c), que usará este banco; fatos com status N ficam de fora das fichas.

### 2026-10-14 — Etapa 5c, documento de design dos encontros (`docs/encontros-5c.md`)

- Escrito a partir do pedido de Arnaldo: os dois formatos (**Mito x Fato** e **perguntas de tema**) e uma **árvore de ligação entre perguntas** para escolher a próxima com base num critério e, se o jogador errar, servir uma pergunta mais simples que ensine o conceito.
- Árvore: 14 nós de conceito e 7 de história (grafo sem ciclos, três níveis de pergunta por nó), estado de domínio de 0 a 4 por nó, prioridade = 4 × relevância da missão + 3 × reforço + 2 × adequação + 1 × variedade, regra de reforço (erro em L2 serve L1 do mesmo nó; erro em L1 serve o pré-requisito mais fraco com uma ficha de reforço), no máximo 3 perguntas por encontro, desempate semeado (mesma sequência de respostas, mesmas perguntas).
- Regras já combinadas: relógio pausado, bônus extra sem mexer nas estrelas, erro sem punição, pular e desligar nas configurações, 2 a 3 encontros por missão em pontos semeados.
- Banco inicial: 40 perguntas rascunhadas, todas com fato de status V no banco de referências (ou cálculo/raciocínio do projeto marcado). A redação final e a checagem de cada trecho na fonte ficam para a 5d-3.
- **Nada foi implementado.** Decisões a confirmar: seção 11 do documento.

### 2026-10-14 — Etapa 5c, documento de encontros revisado com as decisões de Arnaldo

- **Fechado:** 3 encontros por missão (2 fixos semeados + 1 disparado pelo Geiger); caderno de campo **permanente** em todas as missões, com design de caderno de laboratório (seção 6.2); código de turma na URL em aberto; modo competição só no futuro.
- **Pontuação relativa ao máximo:** aproveitamento de 0 a 100% = busca e identificação 55% + tempo 20% + aprendizado 25%; quem desliga os encontros tem os pesos reescalados (73/27) e continua podendo chegar a 100%. As estrelas não mudam. Pesos a calibrar na 5d com a simulação de jogadores sintéticos (o bom caçador que erra todas as perguntas deve manter mais de ~75%).
- **Reforço em cadeia:** errou uma vez → ficha de reforço e pergunta mais simples (sem repetir a errada); acertou → mostra a solução da original; errou → pergunta ainda mais simples; se errar de novo, o jogo ensina as três em ordem, da mais simples à original. Limite recomendado: 3 perguntas por encontro (a árvore tem no máximo 3 níveis por nó mais um pré-requisito; o resto é retomado nos encontros seguintes e no caderno).
- Pendente de confirmação: limite de 3, "pular conta 0% naquele encontro", pesos iniciais. Nada implementado.

### 2026-10-14 — Etapa 5d-1: motor dos encontros, banco de perguntas e aproveitamento (sem interface ainda)

- **Pedido:** implementar os encontros de aprendizado segundo `docs/encontros-5c.md`; esta parte cobre só a lógica, os dados e os testes. O jogo visível **não mudou**.
- **Dados:** `js/data/encontros/conceitos.js` (21 nós: 14 de conceito e 7 de história, com pré-requisitos sem ciclo, ficha de reforço PT/EN e fonte) e `perguntas.js` (55 perguntas Mito x Fato e de alternativas, PT/EN, cada uma ligada a IDs do banco de referências e com status V, V+C ou V+R). A redação ainda é rascunho; a conferência de cada trecho na fonte é a 5d-3.
- **Motor** (`js/encontros/motor.js`, funções puras, sem `Math.random`): escolhe o nó por prioridade (domínio baixo, missão, gatilho, história), desempata por menos visto e sorteio semeado; cadeia de reforço de no máximo 3 perguntas, sem repetir, do mais simples ao original; créditos 1 / 0,5 / 0,25; pular = 0.
- **Aproveitamento** (`js/encontros/aproveitamento.js`): 55% fontes + 20% tempo + 25% encontros. **Decisão de Arnaldo:** desligar os encontros zera os 25% e o teto vira 75%, sem reescalar.
- **Progresso:** `settings.encontros` (padrão ligado) e `aprendizado` (domínio por nó, vezes vista, fichas vistas) saneados em `progresso.js`; lixo no armazenamento é descartado.
- **Testes:** `tests/08-encontros.test.mjs` (15 testes, Node puro; suíte total 98 testes): grafo, ciclos, PT/EN, fatos existentes no banco, determinismo, cadeia, aproveitamento. Simulação de calibração em `tests/simulacao/encontros-sim.mjs` (`RH_ROOT=../current node simulacao/encontros-sim.mjs 300`).
- **Achado da simulação (a decidir):** com os créditos 1 / 0,5 / 0,25, um aluno que acerta só 30% das perguntas ainda recebe crédito médio de ~0,42 por encontro, porque a cadeia dá segundas chances; quem acerta tudo de primeira recebe 1,00. O caçador perfeito que erra tudo fica em 75%, como combinado. Sugiro avaliar créditos menores para a 2ª e a 3ª chance (por exemplo 1 / 0,4 / 0,15) na 5d-4; é um ponto de partida, não uma regra física.
- **Cobertura simulada:** 8 missões x 3 encontros usam ~18 dos 21 nós; repetição de pergunta cai a ~0 para quem acerta quase tudo; para quem erra muito há repetição porque o banco é de 55 perguntas (a 5d-3 deve ampliar L1 e L3).
- Arquivado: `archive/2026-10-14_pre-encontros`; removida a mais antiga (`2026-10-13_pre-modulos`) para manter o máximo de 5.

### 2026-10-14 — Etapa 5d-2: encontros no jogo, caderno de campo e aproveitamento na tela final

- **Pedido de Arnaldo:** usar créditos menores nas chances extras e seguir para as próximas etapas. Créditos agora **1 / 0,4 / 0,15** (eram 1 / 0,5 / 0,25).
- **Correção de uma afirmação minha na 5d-1:** eu disse que as segundas chances inflavam o crédito de quem acerta pouco. A simulação refeita com os novos créditos mostra que quem acerta 30% recebe 0,39 por encontro (antes 0,42): quase todo o crédito vem da **primeira tentativa**, e uma pergunta Mito x Fato dá 50% de acerto no chute. Créditos menores nas chances extras ajudam pouco; para reduzir o efeito do chute seria preciso ter mais perguntas de alternativas e menos binárias nos níveis 2 e 3 (a avaliar na 5d-3).
- **No jogo:** 2 pontos fixos por missão (casas alcançáveis do mapa real, longe da largada e das fontes, sorteio semeado pela missão) e 1 encontro disparado pelo Geiger (detector ligado, sinal contínuo acima de 2x o fundo por 1,5 s, depois de 15 s de jogo); intervalo mínimo de 40 s entre encontros; balão "?" de meio segundo antes do modal (sem animação com movimento reduzido).
- **Modal do encontro** (`js/encontros/ui-encontro.js` + `gerenciador.js`): pergunta, retorno com explicação, ficha de reforço (cartão de papel) ao errar, cadeia de até 3 perguntas, encerramento com as respostas do mais simples ao original e crédito. Teclado (1 a 3, M/F, Enter, Esc = pular) e toque; relógio e movimento parados; botão de pausa e Esc de pausa desativados durante o encontro; sair ou reiniciar a missão cancela o encontro.
- **Fim de missão:** os encontros que não aconteceram no caminho são apresentados antes da tela de conclusão (o relógio já está congelado).
- **Tela de conclusão:** mostra o **aproveitamento** (fontes + tempo + encontros) e, com os encontros desligados, o texto "máximo possível 75%". Configurações: interruptor "Encontros de aprendizado" com o aviso dos 75%.
- **Caderno de campo** (`js/encontros/caderno.js`): folha de caderno com 6 abas por tema, fichas dos conceitos já vistos (com fonte e selos de domínio de 0 a 4) e cartões trancados para o que ainda não apareceu; abre pelo menu e pela pausa; Esc fecha.
- **Testes:** `tests/09-encontros-jogo.test.mjs` (8 testes no Chromium: pontos determinísticos e alcançáveis, relógio parado, Esc, cadeia com 40%, gatilho do Geiger, missão 1 completa com encontros, encontros desligados com teto de 75%, configurações e caderno). O robô das missões foi movido para `tests/helpers/robo.mjs`; os testes antigos de conclusão de missão rodam com os encontros desligados (`semEncontros`), e o 09 cobre o fluxo com encontros ligados na missão 1.
- Arquivado: `archive/2026-10-14_pre-encontros-ui`.
- **Limites declarados:** a aparência foi verificada por capturas de tela no Chromium (desktop e celular 390x844), não em aparelhos reais; `?turma=` e o modo professor continuam fora; o aproveitamento ainda não é gravado por missão (só aparece na tela final).

### 2026-10-14 — Etapas 5d-3 e 5d-4: conferência das perguntas nas fontes e revisão crítica

- **Pedido:** seguir para as próximas etapas. Observação sobre o método: esta rodada rodou no modelo configurado da sessão (Sonnet), não no maior; o que exigiria julgamento de especialista fica sinalizado abaixo.
- **Auditoria das 55 perguntas contra o banco de referências** (cada pergunta e explicação lidas ao lado dos fatos citados) e **releitura direta em páginas originais** dos itens de maior risco. Detalhes e trechos em `docs/referencias-5c/busca/agente-D-5d3.md`. Limite declarado: a ferramenta de leitura devolve extrações feitas por um modelo pequeno, não o HTML nem os PDFs.
- **Confirmados sem divergência:** banana (EPA, 0,01 mrem = 0,1 µSv), limiar de 1 Sv e radônio (OMS 2023), 112.000 monitorados e 249 contaminados e "brilho azul" (AIEA 1988), Fukushima sem mortes por radiação aguda (OMS), Lia (três moradores juntando lenha, AIEA 2014).
- **Correções feitas:**
  1. **N06-3:** a pergunta dizia que o relatório de Goiânia registra "passar pó de césio na pele"; essa afirmação não estava em nenhuma fonte lida. Reescrita como cenário hipotético (pó de césio-137 cai sobre a pele e a roupa), sem atribuir ao relatório.
  2. **N13-3 (fonte órfã):** estava ligada a um fato que não definia o termo. Definição conferida na AIEA (TECDOC-1388, seção 1.5, p. 7; confere com o ICRPaedia, que cita o Glossário de Segurança da AIEA de 2016).
  3. **N06-2 (90% da roupa):** a porcentagem está na página de perguntas frequentes do CDC, não na de "causas"; a citação aponta agora para a página certa.
  4. **N03-1:** "Em geral, temperatura e pressão não mudam a meia-vida" (a fonte do NRC faz ressalva para a forma química em alguns nuclídeos).
  5. **N07-3 e N08-1:** a explicação "cai bastante" virou "dobrar a distância divide a taxa por quatro (fonte pontual)", com a fonte do fator 4.
  6. **N08-3:** o enunciado agora diz "fonte gama pontual" (a lei de 1/d² vale para esse caso).
  7. **N11-2:** a pergunta restringe-se a **efeitos imediatos** (antes, "só o total importa" podia ser defendido para risco de câncer).
  8. **N12-1 e N12-3:** ALARA com a definição do 10 CFR 20.1003; "dose efetiva" no limite de 1 mSv.
- **Acrescentadas 5 perguntas de alternativas e de fato (total 60):** 1 Sv = 100 rem (N05-4), limiar da síndrome aguda (N11-3), limite de trabalhadores com média em 5 anos, em cálculo (N12-4, V+C), fonte órfã parece item curioso (N13-4), metade dos pacientes com câncer faz radioterapia (N14-3).
- **Revisão crítica (5d-4):** testes novos de robustez (15 encontros com respostas, pulos e teclas aleatórios; reiniciar ou sair no meio de um encontro; apagar o caderno). Adicionado em Configurações o botão **"Apagar o progresso do caderno"** (dois cliques), pensado para computadores compartilhados em sala de aula. O teste de IDs de fatos agora exige o cabeçalho exato no banco de referências.
- **Pendências honestas:** (a) a redação em PT/EN foi conferida contra fonte, mas uma **revisão de especialista** sobre a adequação didática e a tradução continua recomendável antes de uso em turmas; (b) os níveis 3 dos nós de história e vários níveis 1 de uma só pergunta continuam escassos (a cadeia de reforço cai no pré-requisito ou numa pergunta do mesmo nível); (c) fatos ainda sem fonte lida (atividade do Co-60 de Mayapuri, fundo natural brasileiro, "Poisson" em fonte oficial) seguem fora do jogo; (d) o chute em perguntas Mito x Fato (50%) infla o crédito, mitigado pelas novas perguntas de alternativas.
- Arquivado: `archive/2026-10-14_pre-5d3`.

### 2026-10-14 — Etapa 5d-5 (escala de confiança, perguntas novas, fontes) e cofre provisório (5e, parte 1)

- **Pedido:** melhorar os 3 níveis; pesquisar a atividade do Co-60 de Mayapuri, o fundo do Geiger e o Poisson; escala de confiança no Mito x Fato; depois o cofre.
- **Mayapuri (corrige "NÃO ENCONTRADO"):** AERB, Gamma Cell GC 220 (AECL), 147,186 TBq (3978 Ci) em 1969 e 688,2 GBq (18,6 Ci) em abril de 2010; meia-vida do Co-60 = 5,27 anos (CDC). A conta de decaimento confere (~0,71 TBq previsto). Era irradiador de pesquisa, não de radioterapia. O "~60 TBq" de versões anteriores não tem fonte. Detalhes: `V5D3.5`.
- **Poisson e fundo:** `V5D3.6` e `V5D3.7`. A faixa típica de fundo é 5 a 60 cpm (0,08 a 1 cps); o jogo usa 5 cps (escala didática [H]). **Decisão pendente do Arnaldo:** recalibrar para ~0,5 a 1 cps muda limiares e testes.
- **Escala de confiança (Mito x Fato):** 5 botões (certeza mito, quase certeza mito, não sei, quase certeza fato, certeza fato; teclas 1 a 5, M e F valem como certeza). Acerto com "quase" vale 70% do crédito; erro com certeza total reduz pela metade o crédito das chances seguintes; "não sei" não tem penalidade.
- **Banco:** de 60 para 74 perguntas (níveis 3 em N01, N02, N04, N05, N07, N10, N11, E-MAY, E-RAD; mais níveis 1 e 2).
- **Cofre provisório:** ao fim da missão, uma pergunta de blindagem por tipo de radiação das fontes. Pesos: fontes 55 + tempo 20 + encontros 15 + cofre 10; desligado = teto de 75%. Será substituído pelo cofre interativo em prateleiras (ideia do Arnaldo), a desenhar.
- Testes: 115/115. Arquivado: `archive/2026-10-14_pre-5e`.
- **Emissões por isótopo (V5D3.8, LNHB/DDEP)** e **prompt para o design do cofre interativo** (Opus): `docs/prompt-cofre-opus.md`. Decisão do Arnaldo: 3 prateleiras (alfa, beta, gama); a fonte vai para a radiação mais penetrante com rendimento significativo; ficha clicável; visual no nível do caderno.

### 2026-10-14 — Etapa 5e, cofre interativo: leitura e plano (nada em `current/` alterado)

- **Pedido:** desenhar o cofre interativo em prateleiras (alfa, beta, gama) que substitui o cofre provisório; começar
  lendo o código e os documentos e apresentar plano e respostas às questões de projeto 1 a 5.
- **Feito:** `docs/cofre-5e-plano.md` (regra de prateleira, coerência com o Geiger, mecânica, ficha, escala, visual, decisões).
- **Achados:** só 6 isótopos são sorteados nas missões (Am-241, Cs-137, Ra-226, I-131, Sr-90, Co-60); o Ra-226 (M3) não
  está em V5D3.8; com a regra proposta a prateleira alfa quase não é usada (Am-241 cai em gama); I-131 e Am-241 têm, no
  Geiger, um só tipo que não corresponde à prateleira; na M5 só o Sr-90 é do acidente real.
- **Aguarda decisões D1 a D5** do plano. Archive e testes inalterados.
- **Revisão (observação do Arnaldo):** Am-241 fica na prateleira alfa; limiar da regra passa de 10 para 50 por 100 decaimentos (seção 2 do plano); D3 deixa de ser necessária.
- **Revisão 2:** Geiger alfa de Am-241 e Ra-226 aceito como coerente (fundo de 5 cps esconde gama fraca a distância); Ra-226 → alfa contando só as emissões do próprio nuclídeo (D2 resolvida); incoerência restante: I-131.
- **Revisão 3 (D5):** I-131 com beta + gama no Geiger, mostrado ao aluno; emissão dominante (alfa no Am-241 e no Ra-226) fica sozinha. A confirmar: mesmo tratamento para Cs-137 e Co-60.
- **Revisão 4:** Cs-137 e Co-60 também beta + gama (aprovado); D4 aprovada; requisito: nenhuma fonte impossível de identificar (testes de detectabilidade e distinção na etapa F). Ordem: A, B, C, F, D, E.

### 2026-10-14 — Etapa 5e-A: mockup visual do cofre (nada em `current/` alterado)

- **Pedido:** Arnaldo aprovou Cs-137 e Co-60 com beta + gama e a mecânica D4; lembrou que nenhuma fonte pode ficar impossível de
  identificar (requisito registrado no plano, revisão 4).
- **Feito:** `docs/cofre-mockup/index.html` (HTML estático, abre direto no navegador, dados da missão 5) e capturas em
  `docs/cofre-mockup/capturas/` (desktop 1280 px e celular 390 px, Chromium headless). Interação completa: selecionar, guardar
  (clique, toque, arrastar ou teclas 1/2/3), retorno imediato, crédito 1 / 0,4 / 0, blindagem por prateleira, ficha com barras de
  emissão e tabela "o que o seu Geiger mostrou", resumo ao lacrar.
- **Verificado:** fluxo completo por script no Chromium, sem erro de JavaScript (só as fontes do Google não carregam no ambiente de teste).
- **Não verificado:** aparelhos reais; leitor de tela; versão em inglês (fica para a etapa D). A tabela do Geiger é prévia do modelo da etapa F.

### 2026-10-14 — Etapa 5e-B: tabela de emissões com fonte

- **Pedido:** mockup aprovado; seguir para os dados.
- **Arquivado:** `current/` em `archive/2026-10-14_pre-cofre` (conferido com `diff -r`); removida a pasta mais antiga
  `archive/2026-10-14_pre-encontros` (o .zip original continua).
- **Novo `js/data/emissoes.js`:** linhas de emissão (tipo, energia, rendimento por 100 decaimentos) dos 11 isótopos do jogo
  (os 10 de `isotopes.js` e o Ra-226 da missão 3), com a fonte de cada um; filho Y-90 do Sr-90 como informação;
  funções `rendimentoPorTipo` e `linhaPrincipal`. Nenhum outro arquivo de `current/` mudou; o jogo ainda não usa a tabela.
- **Ra-226 (novo, V5E.1):** LNHB (Chisté e Bé, 2007): alfa 4784,34 keV 94,038% e 4601 keV 5,950%; gama 186,211 keV 3,555%.
  Prateleira alfa pela regra.
- **Testes:** novo `tests/10-emissoes.test.mjs` (7): cobertura de todos os isótopos, linhas válidas, alfa + beta ≤ 100 por
  decaimento, energias iguais às de `isotopes.js` (até 3%), alcance beta igual ao Katz-Penfold na Emax do LNHB (até 2%),
  rendimentos que decidem as prateleiras, registro das fontes. O script `npm test` agora usa `[0-9]*.test.mjs` (o padrão
  antigo `0*` não pegaria o arquivo 10). **Suíte: 122 testes, todos passam** (rodada numa cópia idêntica no Chromium headless
  da nuvem, porque a pasta `tests/` do seu disco não tem `node_modules`).
- **Limite:** os valores do LNHB foram lidos por extração de PDF; casas decimais devem ser conferidas no PDF antes de citar fora do jogo.

### 2026-10-14 — Etapa 5e-C: lógica pura do cofre (`cofre.js`)

- **Pedido:** "pode continuar" (etapa C, Sonnet, esforço médio).
- **Arquivo:** não arquivei de novo: `current/` difere de `archive/2026-10-14_pre-cofre` só pelo `js/data/emissoes.js` (conferido com `diff -rq`), então
  aquela cópia continua sendo um retorno válido e evitei apagar outra versão antiga à toa.
- **`js/encontros/cofre.js` (parte nova, sem DOM e sem Phaser):** `prateleiraDe` (tipo mais penetrante com rendimento ≥ 50 por 100, só o próprio nuclídeo),
  `motivoDoErro`, `itensDaMissao`, estado imutável (`novoCofre`, `guardar`, `escolherBlindagem`, `completo`, `creditos`, `nota`), `registros` (pseudo-encontros
  para o caderno: N04 por isótopo, N09 por blindagem), `espessuraChumbo` (camada semirredutora e espessura para 1/1000, feixe estreito, sem buildup),
  textos PT/EN (`explicarPrateleira`, `dicaDoErro`, `explicarBlindagem`). A parte do cofre provisório continua no fim do arquivo, marcada, porque
  `gerenciador.js` ainda a usa; sai na etapa D.
- **Regras fechadas:** crédito 1 na 1ª tentativa, 0,4 na 2ª, e depois de dois erros o cofre guarda e explica (0); só se escolhe a blindagem de uma
  prateleira que já recebeu fonte; créditos de blindagem [H] (alfa: papel 1, acrílico ou alumínio 0,7, chumbo ou concreto 0,4; beta: acrílico ou alumínio 1, chumbo e
  concreto 0,4, papel 0; gama: chumbo ou concreto 1, o resto 0); nota = média dos créditos de itens e blindagens, item não feito = 0, e entra em
  `aproveitamento({cofre: creditos(estado)})` (10 pontos).
- **Fonte nova (NIST XCOM, chumbo, Z = 82; consulta de 14/10/2026):** μ/ρ de 30 keV a 1,5 MeV com a borda K (88,0045 keV) tratada em duas faixas. Fecha o [P] do
  Pb a 60 keV: 5,021 cm²/g. Resultados (feixe estreito, energia efetiva, aproximação): Am-241 camada semirredutora ≈ 0,12 mm e 1/1000 em ≈ 1,2 mm; I-131 ≈ 2,2 mm e
  ≈ 21 mm; Cs-137 ≈ 5,5 mm e ≈ 55 mm; Co-60 ≈ 10 mm e ≈ 104 mm.
- **Conferências nos testes:** só 11 isótopos, prateleiras por missão iguais ao plano (M1 α γ; M2 γ; M3 α; M4 e M8 β γ; M5 α β γ; M6 e M7 γ);
  qualquer limiar de 36 a 85 dá o mesmo resultado e 35 move o Am-241 para gama; no máximo 12 interações mínimas por missão; as porcentagens do texto
  ("92% a 96%" em 3 mm de alumínio, "94% a 96%" em 5 mm de acrílico) são recalculadas com `shields.js` e `geiger.js` para Cs-137, Co-60 e I-131
  e só valem para essas fontes (o teste falha se uma missão passar a sortear outra fonte gama).
- **Testes:** novo `tests/11-cofre.test.mjs` (17). **Suíte completa: 139, todos passam** (rodada numa cópia no Chromium da nuvem). Quatro mutações manuais
  (limiar 30, crédito 0,5, ordem de penetração invertida, borda K apagada) foram detectadas.
- **Limites:** a espessura de chumbo é feixe estreito sem acúmulo (buildup): numa blindagem real seria maior; Ir-192 e Tc-99m não aparecem em nenhuma missão.
  Pb em 59,5 keV vem da interpolação log-log entre 50 e 60 keV (NIST), não de uma linha tabelada nesse valor.

### Pendências para confirmação do Arnaldo
- (Aceito por Arnaldo em 13/10/2026, "pode manter tudo do jeito como ficou") O cabeçalho de autoria saiu de `game.js` e está agora, com o
  mesmo texto, no topo de `current/js/main.js`. Um teste
  (`01-dados`) falha se o texto desaparecer de todos os `.js`.

## 2026-10-14 — Etapa 5e-F: Geiger com componentes (beta + gama)
**Pedido:** fontes com mais de uma emissão relevante (I-131, Cs-137, Co-60) devem mostrar as duas no Geiger, mantendo o jogo jogável.
**Mudou:** `js/fisica/componentes.js` (novo), `js/fisica/geiger.js` (soma sobre `fonte.componentes`), `GameScene.js` (linha de emissões no feedback; dica "beta e gama"), i18n PT/EN (+2 chaves, 172→174), `emissoes.js` (energia gama efetiva, alcance beta Katz-Penfold). Arquivo anterior: `archive/…_pre-geiger-comp`.
**Decisões:** componente primária = `type` de isotopes.js (inalterada); secundárias com rendimento ≥50/100 entram com peso = razão de rendimentos; `fatorForca` por tipo segue [H]. Componentes só somam sinal (nunca reduzem).
**Testes:** novo `12-geiger-componentes` (14); `04-geiger` e `01-dados` adaptados (distâncias gama 3–6 tiles; fonte "beta" pode ser I-131). Suíte completa no Chromium (cópia na nuvem): 153 testes, 150 passam; as 3 falhas são testes que leem `docs/` (ausente na cópia) — 10 e 11 passam no dispositivo; o de `08-encontros` (cofre provisório) não foi reexecutado lá.
**Limites:** Co-60 beta só até ~0,7 m; I-131 agora é achado de mais longe (gama); sem teste em aparelho real.
**Estado:** F concluída; próxima Etapa D (UI integrada).

## 2026-10-14 — Etapa 5e-D: cofre interativo integrado ao jogo
**Pedido:** trocar o cofre provisório (uma pergunta por tipo) pelo cofre definitivo do mockup aprovado: 3 prateleiras, fontes clicáveis com ficha, blindagem por prateleira usada, tempo congelado, Esc, pausa bloqueada, PT/EN, acessibilidade, registro no caderno, aproveitamento.
**Mudou:**
- Novos: `js/encontros/cofre-ui.js` (DOM: bandeja, prateleiras, ficha, blindagem, resumo; clique/toque, arrastar com Pointer Events, teclas ← → 1 2 3 Esc, Tab preso no cofre, `prefers-reduced-motion`), `cofre-ficha.js` (dados puros da ficha), `cofre-textos.js` (textos PT/EN da interface), modal `#cofre-modal` em `index.html`, bloco `.cf-*` em `styles.css`.
- Editados: `gerenciador.js` (`cofre()` usa `novoCofre`/`creditos`/`registros`; os créditos do cofre viram `cofreCreditos`, um por isótopo e um por prateleira usada), `ui.js` (registra `ui.cofre`, Esc global ignora o cofre, `hideAllModals` cancela), `GameScene.js` (`uiCofre`), `cofre.js` (seção provisória removida), i18n PT/EN (chave `vaultCounter` removida: 174 → 173 chaves).
- Arquivo anterior: `archive/2026-10-14_pre-cofre-ui`. Para manter no máximo 5 versões apaguei `archive/2026-10-14_pre-5d3` (a mais antiga das pastas) e **mantive** o zip do original `radhunter-original-2026-10-13.zip`, por ser a única cópia intacta da v2.0; avise se preferir o inverso.
**Decisões:**
- A ficha mostra: nome, meia-vida (LNHB via `isotopes.js`), barras de emissão por 100 decaimentos (LNHB/DDEP, `emissoes.js`), a regra da prateleira, a tabela "o que o Geiger mostra" (fração do sinal por blindagem, calculada com as MESMAS funções do jogo) e a espessura de chumbo (feixe estreito, sem buildup, NIST XCOM).
- História: só fatos de `docs/fatos-historicos-3e.md`, e só no par (missão, isótopo) onde o fato vale; sem fato conferido a ficha diz que a fonte é "peça do jogo". Nenhuma atividade em Bq por fonte. **Correção minha ao mockup:** ele dizia "cerca de 1300 TBq cada" para Lia; o registro só tem 1295 TBq (prefácio do relatório) sem dizer se é por fonte, então o número saiu.
- Sair do cofre pede confirmação; o que não foi guardado vale 0 e o caderno registra como pulado.
- Os textos da interface do cofre ficam em `cofre-textos.js` (e não em `i18n/pt.js`/`en.js`) para a lógica rodar em Node; o teste 13 confere paridade PT/EN e marcadores `{n}`.
**Testes:** novos `13-cofre-ficha` (8, Node) e `14-cofre-ui` (9, Chromium: tempo parado, Esc/pausa, 1-2-3 sem trocar a blindagem do Geiger, fluxo certo, erro 1º/2º, blindagem errada, arrastar, sair, inglês, 960×640 sem rolagem e celular 390×844 com ficha em painel inferior, missão 1 de ponta a ponta com o cofre real). Adaptados: `08` (testes do cofre provisório removidos; os do cofre novo estão em 11/13/14), `09` (robô resolve o cofre pela interface), `01` (173 chaves). Suíte completa no Chromium (cópia na nuvem): 167 testes, todos passam; os que leem `docs/` foram conferidos no dispositivo (13 passa lá).
**Limites (o que NÃO foi verificado):** sem teste em leitor de tela nem em aparelho de toque real (só emulação de viewport e Pointer Events em Chromium); contraste das cores não foi medido com ferramenta; os créditos das blindagens e o limiar 50 por 100 continuam [H]; as espessuras de chumbo são de feixe estreito (subestimam o necessário em geometria real).
**Estado:** etapas A, B, C, F, D concluídas. Falta E (revisão crítica completa, docs finais, comando de deploy — não executado).

## 2026-10-14 — Etapa 5e-E: revisão crítica, correções e comando de deploy
**Pedido:** revisão crítica do cofre e fechamento (docs, comando de deploy, sem executá-lo).
**Feito:** autoverificação + revisão independente por agente Opus (só leitura); 10 correções (texto da beta x tabela do Sr-90/Y-90, "fótons por decaimento" acima de 100, foco, Tab no celular, anúncio do retorno por leitor de tela, fantasma de arrasto, cabeçalhos da tabela, contraste, reduced-motion, docs) e testes novos. Detalhes, pendências e limites em `docs/cofre-5e-revisao.md`. Arquivo anterior: `archive/2026-10-14_pre-revisao-e` (apaguei `pre-5e`, a mais antiga pasta; o zip do original continua).
**Testes:** 173 no Chromium (cópia na nuvem), todos passam (172 na primeira rodada; o 173º era erro do meu teste: Playwright não clica em `aria-disabled`).
**Não verificado:** leitor de tela real, toque em aparelho físico, fontes originais LNHB/NIST nesta etapa.
**Estado:** etapas A–F concluídas; nada publicado. Para publicar (você decide e executa):

    netlify deploy --dir=apps/radhunter/current --site=<ID-do-site> --prod

## 2026-10-14 — Caderno do cofre, energias Am-241/Co-60, Mayapuri e conferência geral
**Pedido:** corrigir o registro do cofre no caderno sem comprometer a dinâmica da 2ª tentativa; conferir energias alfa do Am-241 e do Co-60; confirmar o valor final de Mayapuri; conferência geral antes do upload.
**Mudou:**
- `cofre.js` `registros`: agora 1 registro agregado por nó (N04 "Alfa, beta e gama"; N09 "Blindagem") em vez de um por item. Acertar na 2ª tentativa conta como acerto e NÃO abre a ficha; "ruim" em N04 = item errado nas duas tentativas; em N09 = blindagem com crédito < 0,7; erro do nó = mais da metade dos itens feitos ruins; ficha só se algum item foi ruim; nada feito = pulado. Cofre perfeito soma 1 acerto por nó (antes saturava).
- `emissoes.js`: Am-241 ganhou o alfa de 5388,25 keV (1,66/100); o total alfa exibido passa de 97,7 para 99,3 por 100 (teste 12 ajustado). Co-60 já coincidia com a tabela LNHB. Registro V5E.2 em `docs/referencias-5c/busca/agente-D-5d3.md` (nível de extração via resumo de página, não citação literal).
- Mayapuri: 147,186 TBq (3978 Ci) é a atividade de 1969; em abr/2010 ≈ 688,2 GBq (18,6 Ci), conforme slides da AERB (V5D3.5). Corrigidos `fatos-historicos-3e.md`, `encontros-5c.md`, `cofre-5e-plano.md`, `cofre-5e-revisao.md` (o "[N] não consta" estava desatualizado). A ficha do jogo continua sem citar atividade.
- Arquivo anterior: `archive/2026-10-14_pre-caderno`; apaguei `archive/2026-10-14_pre-cofre` (a mais antiga) para ficar com 5 entradas. Removidos `.rh-teste.tgz` e resíduos `._*` do macOS em `tests/`.
**Testes:** novos 4 em `11-cofre` (2ª tentativa sem erro/ficha, cofre perfeito ≤1 acerto/nó, todos revelados, saída antecipada); suíte completa no Chromium (cópia na nuvem, com `RH_ROOT`): 177/177.
**Não verificado:** leitor de tela e toque físico; LNHB lido por resumo, não literal; Mayapuri 2010 só via slides da AERB (relatório completo não lido).
**Estado:** pronto para upload. Nada publicado. Comando (você executa):

    netlify deploy --dir=apps/radhunter/current --site=<ID-do-site> --prod

## 2026-10-14 — Nova verificação (dados, texto, história, jogabilidade)
**Pedido:** revisão antes do upload. Feita por mim + agente Opus independente (só leitura, com consulta a LNHB/NIST/AIEA/Lok Sabha etc.).
**Dados:** valores de Co-60, Cs-137, U-238, Tc-99m, I-131, Ir-192, Am-241, P-32 conferem com o LNHB; tabela do chumbo confere com o NIST XCOM. Sr-90/Y-90, Po-210 e Ra-226 só de memória do agente (não reabertos).
**Corrigido:** story7 PT/EN (atividade Mayapuri: 147,186 TBq em 1969, ~688 GBq em abr/2010, AERB V5D3.5); fact7_2 (12% em 16 anos → 0,5% em 41 anos); fact7_3 (">20 anos" → ">15 anos", compatível com as duas declarações do Lok Sabha); fact5_2 (bremsstrahlung = raios X, não gama); N04-3 (folha fina de Al → placa de alguns mm); 7,7 → 7,8 meias-vidas; "caçadores" → lenhadores (Lia); descrição da missão 6 deixa claro que a clínica é ficção; botão de identificação mostra "β+γ beta e gama" para fontes com 2 componentes (I-131, Cs-137, Co-60), em vez de só "β beta"; doc: "brilho azul" é [V] (AIEA).
**Não alterado (decisões de design suas, a decidir):** (1) Am-241/Ra-226: blindagem "papel certo" ignora a gama de 59,5 keV / 609 keV dos filhos; (2) regra do cofre conta só o próprio nuclídeo (Y-90, Bi-214 ficam de fora); (3) botão de identificação mostra o tipo e lista só fontes ainda não achadas (missões 2, 3, 7 têm 1 resposta possível); (4) beta + chumbo = crédito 0,4 vs. contêiner de chumbo da história de Lia; (5) Geiger ignora a gama do Am-241; (6) dica beta+gama generaliza para Sr-90/P-32.
**Fatos históricos sem fonte aberta (N):** frases de Marie Curie (fact3_3/3_4), Ra-228 na tinta, Grace Fryer/acordo de 1928, INSAG-7, contêiner de chumbo de Lia, fatores de dose 7×/5×/3× do CSN, BARC 3,1 Gy, Fukushima OMS/AIEA 2015, CNEN NN 3.01.
**Testes:** 177/177 no Chromium (cópia na nuvem, RH_ROOT definido). Arquivo anterior: `archive/2026-10-14_pre-verificacao` (apaguei `pre-cofre-ui`; 5 entradas).

## 2026-10-14 — Pesquisa histórica ampla + dica beta+gama
**Pedido:** (a) nota do usuário: o Geiger real não detecta a gama de 59,5 keV do Am-241 → o jogo fica como está (minha observação anterior estava errada); (b) melhorar a dica beta+gama; (c) pesquisa mais abrangente dos fatos históricos.
**Feito:** 4 pesquisas independentes (Curie/Radium Girls; Goiânia/Zaragoza; Chernobyl/Fukushima/CNEN; Lia/Mayapuri) com fontes abertas; resultado completo em `docs/fatos-historicos-3e.md` (seção "Verificação ampla de 14/10/2026", com V/N).
**Mudou nos textos:** story2 (retirada 13/09 e ruptura 18/09 separadas; "duas pessoas"; depósito provisório; beta e gama), story3 (Ra-228 em algumas fábricas desde ~1919; renda "enquanto vivessem"), story4 (116.000 "primavera e verão"; tireoide "até 2002"; gatilho exato desconhecido, INSAG-7), story5 (cilindros a ~10 cm; "sem supervisão nem controle" em vez de "deixou de ser soviética"; floresta abaixo da represa), fact3_3/3_4 (Curie = declaração à imprensa), fact6_3 (7× CSN vs ~9× AIEA), fact7_1/7_3/7_4 (1969 Parlamento/AERB; >15 anos com nota de >20; idade removida), fact8_2 (341 documentos removido), Fukushima/OMS → AIEA 2015 (pergunta N-FUK, ficha de conceito), Po-210 (Marie e Pierre Curie, 1898), Cs-137 "esteve no centro" do acidente, ficha do cofre do Ra-226. Dica `betaGammaHint` reescrita como procedimento: medir sem escudo, depois com Al/acrílico (o que some é a beta), o que sobra é a gama (só chumbo derruba).
**Não verificado / ainda [N]:** Hoffman 1925 e "Radium Dangers" 1906; INES 7, 110.000/165.000/37.000 e Tóquio 250 km (só BASE); 670/580 mSv/h; limiar de 1 Sv "segundo a OMS"; autorização jan/1970 e FIR 08/04 (Mayapuri); frase da OMS sobre ~50 mortes em Chernobyl (contexto). Leituras via WebFetch são resumos de página.
**Testes:** 177/177 no Chromium (cópia na nuvem). Arquivo anterior desta rodada: o `archive/2026-10-14_pre-verificacao` (anterior a ambas as rodadas de correção de texto); archive com 5 entradas.
**Estado:** pronto para upload; nada publicado. Comando (você executa):

    netlify deploy --dir=apps/radhunter/current --site=<ID-do-site> --prod

## 2026-10-15 — Publicação
Deploy de produção feito pelo usuário (sem rascunho prévio): `netlify deploy --dir=apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod`. Deploy ID 6ad0f2df79ea3c81f1397d96, 46 arquivos, https://radiationhunters.netlify.app. Para reverter: painel do Netlify > Deploys > deploy anterior > "Publish deploy". Site ID registrado aqui para próximos comandos.

## Câmera, mapas grandes e interface de celular (2026-10-15)
**Pedido:** preparar a tela e o mapa para mapas maiores que a tela (inclusive no computador) e tornar o jogo jogável no celular, com botões visíveis e visual moderno. Decisões do usuário: só a capacidade (nenhuma missão foi ampliada), câmera que segue o jogador com suavização, joystick analógico flutuante, retrato e paisagem com layouts próprios.
**Mudanças:**
- Canvas agora acompanha o contêiner (`Scale.NONE`, resolução = tamanho × dpr, dpr limitado a 1,5; `ResizeObserver` + `orientationchange`).
- `GameScene.ajustarCamera()`: zoom adaptativo, mapa pequeno centralizado, mapa grande com `startFollow` (lerp 0,12) e limites; missões aceitam `mapCols/mapRows` opcionais (padrão 24×16). Minimapa proporcional ao mapa, com retângulo da vista.
- Joystick analógico flutuante (`#joy-zone`) substitui o direcional; botão Correr; HUD translúcido sobre o mapa no celular.
- Testes: `15-camera.test.mjs` (novo); `02`, `06`, `07` atualizados. Suíte completa: 184/184 (ambiente em nuvem, Chromium headless).
**Não verificado:** celulares reais (toque, desempenho do renderer Canvas em dpr 1,5), leitores de tela, outros navegadores.
**Estado:** não publicado. Backup anterior em `archive/2026-10-15_pre-camera`.

## Novo personagem (2026-10-15)
**Pedido:** personagem mais bonito e moderno, que se identifique com o jogo. Decisões: cientista de campo (jaqueta laranja de alta visibilidade com faixas refletivas, capuz branco com visor ciano, mochila com trifólio), desenhado por código, um personagem, 4 direções, parado/andar/correr.
**Mudanças:** novo `js/render/personagem.js` (texturas `cacador_<dir>_<n>`, 3 quadros por direção; direita = espelho da esquerda). `GameScene` usa o sprite; o detector Geiger gira em torno do personagem apontando à frente (ficando atrás do corpo ao andar para cima); ciclo de passos mais rápido ao correr. `geigerIndicator`/`geigerTip` mantidos (cores do Geiger inalteradas). Teste novo em `15-camera.test.mjs`. Suíte: 184/184 antes do teste novo; `15-camera` 8/8 depois.
**Backup:** `archive/2026-10-15_pre-personagem` (removido o mais antigo, `pre-caderno`; archive com 5 entradas).
**Não verificado:** aparência em celulares reais; correr/andar em ritmo real de dispositivo lento.

## Acessibilidade das fontes (2026-10-15)
**Pedido:** a fonte da missão Radium Girls parecia muito difícil de detectar; verificar se todas as fontes ficam em lugares acessíveis e garantir isso no sorteio.
**Auditoria (antes de mudar):** em 25 mapas sorteados da missão 3 (100 fontes) e em amostras das demais missões, toda fonte já caía num móvel alcançável; a menor taxa líquida medível (melhor posição, mira em 8 direções) foi 40,6 cps na M3. Ou seja, não encontrei fonte presa ou inalcançável; a dificuldade vem da regra didática do alfa (só conta a ≤ 1 tile da superfície do móvel, de frente, sem parede no meio).
**Mudança (garantia):** novo `js/fisica/acessibilidade.js` (varredura das posições alcançáveis com a colisão real + melhor taxa por móvel). `GameScene.placeSources()` só sorteia móvel com taxa líquida >= 25 cps; se faltar, relaxa para 15, 8 e, por último, qualquer móvel. Física do Geiger inalterada.
**Testes:** `16-acessibilidade.test.mjs` (7 testes). Suíte: 192/192.
**Backup:** `archive/2026-10-15_pre-acessibilidade` (removido `pre-geiger-comp`; archive com 5 entradas).
**Em aberto (decisão do usuário):** tornar a M3 mais fácil mexendo no alcance do alfa (`alfaAlcanceTiles`, hoje 1,0) ou com pista visual; não alterei.

## Assistência do alfa por tempo (2026-10-15)
**Pedido:** ajudar o jogador frustrado na detecção do alfa (Radium Girls e Am-241), sem mudar o desafio inicial. Decisão do usuário: regra dupla.
**Regra [H, valores de jogo, não físicos]:** o alcance do alfa sobe de 1,0 para 1,5 tile (0,5 m -> 0,75 m) quando o tempo de jogo (sem pausa nem encontros) passa de 75% da meta da missão, ou de 50% da meta se ainda faltam mais da metade das fontes. Só liga se ainda houver fonte com componente alfa por achar. Aparece um aviso e a tela final registra "assistência ativada". A pontuação não mudou (o bônus de tempo já reflete a demora). Parâmetros em `data/config.js` (`ASSIST_*`).
**Código:** `GameScene.verificarAssistencia()`; `fisica/geiger.js` aceita `ctx.alfaAlcanceTiles`; textos `assistAlfa`/`assistAlfaFim` (pt/en, 175 chaves).
**Testes:** `17-assistencia.test.mjs` (5); `01-dados` atualizado (175 chaves). Suíte: 197/197.
**Backup:** `archive/2026-10-15_pre-assistencia` (removido `pre-verificacao`; archive com 5 entradas).
**Não verificado:** se 75%/50% são bons valores com jogadores reais; o identificar continua exigindo ≤ 1,0 tile (só a detecção foi ampliada).

## Academia: mapa grande de 8 salas (2026-10-15) — etapa 1 de 4
**Pedido:** ampliar o tutorial (missão 1), chamá-lo de Academia, e permitir pular. Plano em 4 etapas publicáveis: (1) mapa grande, (2) portas/itens/inventário/chaves, (3) progressão e Geiger achado, (4) conteúdo didático por sala. Esta entrada cobre só a etapa 1.
**Mudanças:** novo `js/mapa/academia.js` (57 x 33 tiles, 8 salas de 13 x 15 em serpentina 1->2->3->4->5->6->7->8, portas de 2 tiles entre salas consecutivas, móveis junto às paredes e faixas das portas livres). `MapGenerator` usa o layout quando a missão tem `layout: 'academia'`; `mapData.salas` expõe as salas. Missão 1: `numSources: 8`, `umaFontePorSala`, `timeLimit: 900` [H], isótopos Am-241 e Cs-137; título "Academia do Caçador" / "Hunter Academy", história ajustada (8 salas). `placeSources` põe uma fonte por sala, respeitando a acessibilidade. Botão "Pular a Academia" no cartão da missão 1 (`progresso.pularAcademia()` libera a missão 2 sem estrelas).
**Testes:** `18-academia.test.mjs` (6): geometria, uma fonte por sala e todas alcançáveis/detectáveis (3 sementes), câmera no mapa grande, botão de pular. Os testes de motor usam por padrão o laboratório compacto antigo (opção `academia: true` no helper liga a Academia). Suíte: 203 (202 + `01-dados` corrigido para 176 chaves).
**Backup:** `archive/2026-10-15_pre-academia` (removido `pre-camera`; archive com 5 entradas).
**Não feito (próximas etapas):** portas e chaves de verdade, itens, inventário, Geiger como item, quizzes por sala, conteúdo didático. As salas ainda não têm nome nem lição própria; as 8 fontes são Am-241/Cs-137 alternadas.
**Não verificado:** a meta de 900 s é palpite; jogo no celular real e a distância total a percorrer (mapa 4x maior que o antigo).

## Academia: corredor central, portas trancadas, chaves e inventário (2026-10-15) — etapa 2 de 4
**Pedido:** corredor central e algumas salas fechadas e mais escondidas; chave na sala 1 abrindo outra sala; ~1/4 das salas fechadas. Regras aprovadas: pegar a chave só passando perto (sem botão), porta abre sozinha com a chave, inventário em barra de ícones, garantia contra jogo travado.
**Layout novo (`mapa/academia.js`, 57 x 33):** corredor central de 5 tiles entre duas fileiras de 4 salas (13 x 12). Salas 1-3 e 5-7 abrem para o corredor e se ligam às vizinhas por portas abertas. Salas 4 e 8 (25%) não têm porta para o corredor: só se entra por porta trancada na sala ao lado (3->4 azul, 7->8 vermelha). Chave azul na sala 1; chave vermelha dentro da sala 4.
**Código:** tile 3 = porta trancada (bloqueia e conta como parede; vira 0 ao abrir). `GameScene.criarPortasEChaves()` sorteia a posição de cada chave num piso alcançável com as portas anteriores já abertas (cadeia resolvida); `verificarPortasEChaves()` (pegar ao passar a < 0,8 tile; porta abre a < 1,0 tile com a chave; aviso sem chave a cada 4 s); inventário em `#inventory` (`ui.atualizarInventario`), minimapa mostra as portas em dourado. Textos pt/en (182 chaves de tradução). `GameState.inventario` zera a cada partida.
**Testes:** `18-academia.test.mjs` reescrito (8): geometria; 4 sementes verificando que as salas 4 e 8 são inalcançáveis sem chaves, a azul se pega sem nada, a vermelha só depois da azul, todas as salas ficam alcançáveis com as duas, uma fonte por sala e detectável; fluxo de jogo (aviso, pegar, inventário, porta abre); câmera; botão de pular. Suíte: 205/205.
**Backup:** `archive/2026-10-15_pre-chaves` (removido `pre-acessibilidade`; archive com 5 entradas).
**Não verificado:** celular real (tamanho dos alvos, inventário no canto), balanceamento do tamanho do mapa, ícones/sons definitivos das portas. Etapas 3 (Geiger como item e progressão) e 4 (lições e quizzes por sala) ainda não feitas.

## Academia: lições lineares, Geiger como item e travas (2026-10-16) — etapa 3 de 4
**Pedido:** aprendizado linear (radioatividade, radiação, ionizante x não ionizante, Geiger com blindagem para identificar o tipo). Currículo em rascunho no doc "Academia do Caçador — currículo linear"; decisões do usuário: ordem das salas aprovada; Sr-90 como beta (mesmo não puro, a menos que recém-separado); Geiger na sala 4; erro no quiz só explica (sem repetir, sem efeito nas estrelas); fronteira ionizante/não ionizante ensinada com UV-A, UV-B e UV-C.
**Mudanças:** (1) a Academia começa SEM Geiger: botões Geiger/Identificar ocultos, tecla G avisa; o Geiger é um item na sala 4 (pegar passando perto; aparece no inventário). (2) 8 painéis de lição, um por sala (`js/academia/licoes.js`, textos pt/en com rótulo [V]/[H]/[N] por lição; `js/academia/ui-licao.js`, modal). A lição abre ao chegar perto do painel; relógio e movimento param. Linear: lição i só abre depois da i-1; a da sala 4 exige o Geiger. (3) Portas: azul exige chave + lições 1 a 3; vermelha exige chave + lições 4 a 7. (4) Fontes só nas salas 4 a 8 (5 fontes): sala 4 Cs-137, sala 5 Cs-137, sala 6 Sr-90, sala 7 Am-241, sala 8 sorteada entre os 3. (5) Conclusão da Academia exige as 5 fontes E as 8 lições, em qualquer ordem. (6) Meta de tempo 1200 s [H] (palpite; o tempo de leitura não conta). (7) Lição 3 traz UV-A 315-400 nm, UV-B 280-315 nm, UV-C 100-280 nm [V: OMS e ICNIRP, páginas abertas]; UV é não ionizante e fica ao lado da região ionizante [V: ICNIRP]; o valor da fronteira em energia não consta nessas páginas e não é usado [N].
**Fontes abertas nesta etapa:** EPA Radiation Basics, NRC Unit 1, OMS UV Q&A, ICNIRP UV. Ainda [N] (física geral sem página aberta): raio X/gama como ondas eletromagnéticas, "menor comprimento de onda = maior energia", Geiger responde à ionizante, inverso do quadrado, princípio tempo-distância-blindagem.
**Testes:** novo `19-licoes.test.mjs` (5); `18-academia` atualizado (5 fontes, 3 vagas no inventário, porta exige lições); `11-cofre` (missão 1 agora tem alfa, beta e gama); helper `navegador.mjs` limpa os campos novos. Suíte: 210/210. Aprendizado: nos testes, não devolver o container do Phaser de `page.evaluate` (a serialização levava ~10 s).
**Backup:** `archive/2026-10-16_pre-licoes` (removido `2026-10-15_pre-academia`; archive com 5 entradas).
**Não feito (etapa 4):** a lição 7 não tem demonstração de decaimento; o painel de lição é só texto + quiz (sem arrastar cartões como no currículo); revisão dos textos pelo autor; sem etapa de publicação. Chave i18n: textos das lições ficam em `academia/licoes.js` (fora das 182 chaves).
**Não verificado:** celular real (painel de lição, toque nas alternativas), balanceamento do tamanho do mapa e da meta de 1200 s, se o jogador percebe os painéis como interativos.
**Publicar (não executado):** `netlify deploy --dir=apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f` (rascunho; testar em celular real, retrato e paisagem), depois com `--prod`.

### Academia, etapa 3 — revisão dos rótulos e lição 7 (2026-10-16)
**Pedido:** explicar os itens [N] e melhorar a lição 7.
**Verificação (páginas abertas hoje):** passaram a [V]: raios X e gama como radiação eletromagnética de alta energia e ionizante, e comprimento de onda maior = energia menor (CDC, espectro eletromagnético); Geiger detecta por ionização do gás (NRC, What is a Geiger Counter); inverso do quadrado para fonte pequena, 1 pé -> 2 pés = 1/4 da taxa de dose (NRC, SART cap. 4, slide 16); tempo, distância e blindagem (EPA RadTown, atividade 2); meia-vida, exemplo de 100 átomos, Tc-99m 6 h, U-238 ~4,5 bilhões de anos, <1% após 7 meias-vidas (NRC glossário; CDC isótopos). Continua [N]: que cada átomo decai ao acaso e só o conjunto é previsível (não consta nas páginas abertas). Achado que mudou o texto: o NRC diz que o Geiger NÃO identifica fonte, tipo nem energia; as lições 4 e 6 agora dizem que o tipo é só uma pista pela comparação de leituras com e sem blindagem.
**Lição 7:** texto reescrito (definição, 100 átomos, faixas de valores, meias-vidas do jogo Sr-90 28,8 a, Cs-137 30 a, Am-241 ~433 a), 3 perguntas e demonstração interativa de 64 átomos (a cada passo, 50% de chance por átomo; modelo de jogo [H]) em `ui-licao.js`. Estilos em `styles.css`.
**Testes:** `19-licoes` (6). Suíte parcial: 19 e 01-dados passam (suíte completa foi 210/210 antes desta revisão).
**Backup:** `archive/2026-10-16_pre-licao7` (removido `2026-10-15_pre-assistencia`; archive com 5 entradas).

### Correção de enquadramento do Geiger (2026-10-16)
**Feedback do usuário:** o desafio do jogo é discriminar entre candidatas CONHECIDAS (o jogador já vê isótopo e tipo de emissão de cada candidata); Geiger, distância e blindagem são pistas que eliminam candidatos até fechar o diagnóstico. A frase do NRC (Geiger não identifica fonte, tipo nem energia) vale para fonte DESCONHECIDA e não contradiz o jogo; eu a tinha apresentado como achado que afetava o jogo — foi leitura equivocada minha.
**Mudança:** lições 4 e 6 reescritas nesse sentido (nova seção "Fechando o diagnóstico" na 6; rótulos de fonte dizem "fonte desconhecida"). Só texto em `academia/licoes.js`; `19-licoes` passa (6/6). Sem novo backup (alteração de texto sobre `archive/2026-10-16_pre-licao7`).

## Academia: orientação no mapa grande e interface (2026-10-16) — rodada de verificação e melhorias
**Pedido:** nova rodada de verificação e melhorias de interface/jogabilidade, principalmente no multimapa (Academia).
**Auditoria (capturas desktop 1280x720 e celular 390x844, rota medida por BFS):** (1) botões do painel de lição sem estilo (branco padrão do navegador); (2) nada orientava o jogador num mapa 57x33; (3) a chave azul na sala 1 obrigava ~32 tiles de ida e volta depois da lição 3; (4) o cone de visão aparecia antes de o jogador ter o Geiger. Rota total de lições, chaves, Geiger e painéis: ~250 a 270 tiles em 6 sementes (a 2,5 tiles/s de caminhada [valor de `PLAYER_SPEED`, unidade não conferida] seria da ordem de 2 minutos só andando; a meta de 1200 s continua palpite [H]).
**Mudanças:**
- **Objetivo na tela** (`academia/objetivo.js`, puro): HUD mostra "Lições n/8 · Fontes a/5" e "Próximo: ..." na ordem linear lição 1 > chave azul > lições 2-3 > porta azul > Geiger > lição 4 > chave vermelha > lições 5-7 > porta vermelha > lição 8 > fontes (indica só a sala, nunca o móvel). Se o jogador sair da ordem, o objetivo recalcula.
- **Seta de caminho** em volta do jogador, apontando o próximo passo por BFS (contorna paredes; não é linha reta); some perto do alvo, com as dicas desligadas (Configurações) e durante modais.
- **Minimapa:** painéis (ciano pendente, verde feito), chaves, Geiger no chão e anel pulsante no alvo do objetivo.
- **Revisar lição:** tecla E perto de um painel concluído, ou toque/clique nele (até 2,2 tiles): só o texto, sem quiz, não conta de novo.
- **Painel de lição:** botões estilizados, alvos de toque de 44 px, "Ir para o quiz"; alternativas certa/errada coloridas.
- **Cone de visão** só depois de pegar o Geiger.
**Testes:** `20-objetivo` (5: ordem do objetivo, textos pt/en, BFS e pontoAdiante, 10 sementes com tudo alcançável e sem itens sobrepostos, HUD/seta/minimapa/revisão) e `21-academia-completa` (3 sementes: partida inteira seguindo só o objetivo da tela até concluir, 5 fontes identificadas pelo Geiger). Suíte completa: 216/216 antes de adicionar o 21; o 21 passa (3/3).
**Backup:** `archive/2026-10-16_pre-objetivo` (removido `2026-10-15_pre-chaves`; archive com 5 entradas).
**Não verificado:** celular real (toque no painel, tamanho da seta e dos alvos, desempenho do canvas com a seta); se a seta incomoda quem já conhece o mapa (hoje só desliga em Configurações > dicas); equilíbrio da meta de tempo.

## 2026-10-16 — Celular: história e lições em partes
- Pedido: no celular a história inicial da missão estourava a tela e o botão ficava inacessível; textos longos (lições/quiz) deveriam aparecer em partes, como a história.
- Causa provável do estouro: altura em `100vh` (no celular inclui a barra do navegador). Agora o contêiner usa `100dvh` + `env(safe-area-inset-*)`, o texto rola dentro dele e a barra de botões fica fixa no rodapé. [V no Chromium headless com viewports 390×844, 360×640, 844×390, 667×375; NÃO verificado em celular real]
- História da missão: dividida em partes (`js/paginar.js`, limite de caracteres estimado pela área visível), botões Voltar / Próximo / Continuar e "Parte i de n".
- Lições: teoria em partes (Voltar/Próximo); demo da lição 7 em parte própria; fonte só na última parte; "Ir para o quiz" só na última; Esc continua adiando; barra de botões fixa (sticky) também no quiz.
- Testes: novo `22-paginacao` (5); helpers `passarHistoria` e `lerLicao`; testes 02/19/20/21 ajustados. Suíte: 224/224.
- Arquivo: `archive/2026-10-16_pre-paginacao` (removido o mais antigo, `2026-10-15_pre-personagem`; 5 itens).
- Não verificado: toque/desempenho em aparelho real, outros navegadores, leitor de tela.

## 2026-10-16 — Posição da alternativa certa no quiz
- Pedido: a resposta certa não deveria ser (quase) sempre a primeira. Verificado: das 13 perguntas, 12 tinham `certa: 0`.
- Mudança: alternativas reordenadas em `licoes.js` (pt e en idênticos). Posições da certa: 1ª=4, 2ª=4, 3ª=5, sem repetir 3 seguidas. Texto das alternativas e explicações inalterado.
- Testes: 19 agora exige certa fora da 1ª posição em ≤40% das perguntas, uso das 3 posições e pt/en coincidentes; teste de "resposta errada" escolhe uma alternativa que não é a certa. 19/20/21/22 passam (suíte completa não repetida: mudança só em dados de lição).
- Arquivo: `archive/2026-10-16_pre-alternativas` (removido `pre-licao7`; 5 itens).
- Observação: a alternativa certa costuma ser a mais longa em algumas perguntas (pista involuntária); não alterei o texto.

## 2026-10-16 — Quiz: ordem das alternativas sorteada
- Pedido: ainda parecia haver muita resposta certa na posição "1".
- Dados já estavam rebalanceados (1ª=4, 2ª=4, 3ª=5 de 13), então o relato pode vir de uma versão publicada antes do rebalanceamento; não consegui verificar o que está no ar.
- Mudança: `ui-licao.js` sorteia a ordem das alternativas toda vez que a pergunta é mostrada; a certa nunca repete a posição da pergunta anterior; teclas 1–9 e destaque seguem a ordem exibida. Dados em `licoes.js` inalterados (índice original).
- Testes: 19 (+1: 40 aberturas, certa aparece nas 3 posições, nunca repete, posição exibida coerente); 19/20/21/22 passam; suíte completa não repetida.
- Arquivo: `archive/2026-10-16_pre-sorteio` (removido `pre-licoes`; 5 itens). Encontros (perguntas.js) já embaralhavam.

## 2026-10-16 · Pente fino de textos, conceitos e perguntas (PT-BR/EN)
- Pedido: revisar ortografia PT-BR/EN, referências, clareza dos conceitos e correção/clareza das perguntas, com ciência justa (aproximações declaradas).
- EN padronizado em inglês americano (cesium, aluminum, millimeter, behavior, color, traveling); "Beta-M".
- story1/mission1Desc agora batem com o mapa (8 salas; 5 fontes nas salas 4–8; salas 4 e 8 trancadas).
- Descrições/dicas alfa e beta: alfa = poucos cm de ar/papel/camada externa da pele; beta de alta energia (Sr-90/Y-90) é só reduzida por Al/acrílico (coerente com a simulação das placas).
- Lição 6: regras de leitura corrigidas (Sr-90 cai muito mas não zera; Cs-137 = patamar de gama que só o chumbo reduz). Lição 4: alternativa errada absurda trocada. Lição 7: trecho enxugado.
- radiumHint sem "brilha verde" (fósforo ZnS; cor não verificada). fact2_1: gama do Cs-137 vem do Ba-137m. fact3_1: Hoffman/JAMA 1925 (~5 mortes, 12 casos), removido "Radium Dangers 1906" (não verificado). fact5_1: certificado ≈1 Sv/h vs medidas 670/580 mSv/h (IAEA Lia). fact8_1: removido "250 km" (não consta na fonte).
- Perguntas: N01-5 (2–3 mSv/ano), N11-1 (1 Sv ou mais), E-MAY-3 (2^-7,8 ≈ 0,5%).
- Testes: 225/225. Backup: archive/2026-10-16_pre-revisao (removido o mais antigo, o zip original, pelo limite de 5).
- Pendente (não verificado [N]): citações de Curie (segunda mão), ano de compra de Mayapuri, teste em celular real.

## 2026-10-16 · Etapas 1 e 2 do relatório de análise (P0 conceitual + modo professor)
- Pedido: aplicar as etapas 1 e 2 do plano derivado do relatório `analise_radiation_hunters.md`.
- Etapa 1 (textos PT/EN): N05 (Bq/Gy/Sv; Sv não mede lesão; contagem do Geiger não dá dose), N06 (exposição inclui material incorporado; radiografia não transfere material), N11 e perguntas ligadas (efeito agudo em Gy; 1 Gy ≈ 1 Sv para raios X/gama é simplificação [H]), N12 e pergunta do limite (1 mSv vale para o público, não é teto de exame médico). Limite CNEN NN 3.01 ainda sem conferência na norma vigente [N].
- Etapa 2: Phaser 3.60.0 local em `current/vendor/phaser.min.js` (sem CDN de script); `js/modo.js` (versão 2.1 · 2026-10-16, `?missao=N`, `?estudo=1`); aproveitamento com `semTempo` (modo estudo reescala fontes/encontros/cofre para 100%); versão no menu; chaves i18n 182 → 184.
- Testes: 229/229 (novo `tests/23-modo-professor.test.mjs`; `tests/01-dados` atualizado para 184).
- Backup: `archive/2026-10-16_pre-modo-professor` (removido o mais antigo, `pre-alternativas`, pelo limite de 5).
- Pendente: publicar (draft, depois --prod) e testar em celular real com `?missao=2&estudo=1`; demais itens do relatório (identificação "dados insuficientes", missão de investigação/hospital) não iniciados.

## 2026-10-16 · Etapa 3: evidência na identificação e "Ainda não dá para concluir" (P0.5 do relatório)
- Pedido: continuar o plano derivado do relatório (opção de não concluir quando os dados não bastam).
- Modal de identificação: mostra a evidência reunida (○/✓ leitura sem placa, leitura com placa) e o botão "Ainda não dá para concluir". O botão não conta tentativa, não tira pontos nem combo; a orientação muda conforme haja ou não comparação (sem placa + com placa, com sinal acima do limiar).
- Acertar sem ter comparado placas mostra uma "nota de método" (no mundo real, uma leitura isolada não identifica a fonte); a pontuação NÃO muda. A evidência zera a cada fonte achada e a cada reinício.
- Decisão de projeto [H]: o jogo continua com lista fechada de candidatos; não há cenário em que "dados insuficientes" seja a única resposta correta (isso ficaria para a missão de investigação).
- Chaves i18n 184 → 190. Testes: 233/233 (novo `tests/24-dados-insuficientes.test.mjs`).
- Backup: `archive/2026-10-16_pre-dados-insuficientes` (removido `pre-objetivo`, o mais antigo).

## 2026-10-16 · Investigação 1: "Hospital: de onde vem a imagem?" (protótipo 0.1-teste)
- Pedido: implementar o roteiro e deixar os humanos (João Vitor e outros) revisarem jogando.
- Novo tipo de missão sem mapa nem Geiger: `js/investigacao/` (motor puro, dados bilíngues, interface DOM). 7 cenas: hipótese inicial, equipamento liga/desliga, caminho da radiação, comparação com frasco (outro contexto), cartaz (cartões com generalizações), mensagem central, retomada (medicina nuclear). Cada alternativa errada tem retorno próprio; evidência escolhida por cartão (sem texto livre); alternativas e cartões embaralhados a cada exibição.
- Ficha final (hipótese inicial, evidências, decisão, revisão, limite, fontes) com exportação `.json` e resumo copiável; campo "Observação para os revisores" em cada cena entra na exportação.
- Acesso: menu > Selecionar missão > cartão "Investigação 1" (área própria sob as 8 missões), ou `?investigacao=hospital`. Sem pontuação, sem tempo, sem gravação de progresso.
- Fontes [V] abertas hoje: CDC (exposição x contaminação), RadiologyInfo (segurança; medicina nuclear). [N]: tubo só produz raios X quando ligado. Roteiro e pontos de revisão em `docs/roteiro-hospital-investigacao.md`.
- Testes: 240/240 (novo `tests/25-investigacao.test.mjs`; `tests/23` ajustado). Backup: `archive/2026-10-16_pre-investigacao` (removido `pre-paginacao`, o mais antigo).
- Pendente: revisão por físico médico; teste com professores; publicar.

## 2026-10-16 · Modo de revisão opt-in (credibilidade do jogo)
- Pedido: o jogo não pode exibir observações para revisores; isso só deve existir se o revisor ligar um "modo de revisão" nas configurações.
- Configurações > "Modo de revisão" (`settings.revisao`, padrão desligado). Desligado: sem campo de observação, selo, aviso de protótipo nem rótulos [V]/[N]/[H] na investigação; aparece uma nota neutra (conteúdo fictício/educativo) e as fontes públicas. Ligado: selo, aviso, rótulos e campo de observação por cena (salvo em `radiationHuntersRevisao`, com "Baixar observações").
- Alternativas da investigação reequilibradas (a correta é a mais longa em 5/16 cenas; razão máx. 1,22).
- Chaves i18n 190 → 192. Testes: 243; 242 passaram na rodada completa e a única falha era a asserção antiga de `03-robustez` (sem `revisao:false`), corrigida e reexecutada (6/6).
- Backup: `archive/2026-10-16_pre-modo-revisao` (removido `pre-revisao`, o mais antigo).
- Pendente: ainda existem rótulos [V]/[H] visíveis nas lições da Academia (anterior a esta mudança) — decidir se também passam para o modo de revisão.

## 2026-10-16 · Conferência do relatório e correções (2.1.1)
- Matriz de atendimento e limites em [docs/conferencia-relatorio-2026-10-16.md](docs/conferencia-relatorio-2026-10-16.md). A carteira de expansões não está inteiramente implementada.
- Investigação hospitalar 0.2-teste: hipótese preservada após sair da recepção; histórico de tentativas/retornos e cartões no JSON (esquema 2), versão do jogo e fontes; sessão parcial não afirma revisão final; notas corrompidas saneadas.
- Ajustes PT/EN: dose absorvida e efeitos agudos, exposição, referência ANSN 3.01 (Resolução CNEN 344/25), radiação ionizante no cartaz, aparelho energizado versus emissão. Fontes em docs/referencias-5c/busca/revisao-2026-10-16.md.
- Nova questão N10-7: insuficiência de informações para identificar radionuclídeo. A limitação da identificação por candidatos no mapa continua registrada.
- Foco de teclado e descrição do SVG melhorados; cartão hospitalar acionável por teclado. Caderno usa “Progresso nos encontros”, preservando as regras existentes.
- Testes 07/08 corrigidos para RH_ROOT opcional; regressões em tests/26-revisao-relatorio.test.mjs; leitura efetiva do JSON em tests/25-investigacao.test.mjs. Resultado consolidado no relatório de conferência.
- Backup: archive/2026-10-16_pre-conferencia-codex-134533.tar.gz. Nenhum arquivo morto excluído. Não publicado.

## 2026-10-16 · Hospital integrado ao mesmo jogo (2.2)
- Requisito: manter estrutura, personagem, movimento, colisão, câmera, HUD e linguagem visual; novos NPCs/móveis podem ser acrescentados dentro dela.
- `HospitalScene` herda a `GameScene` existente. Usa `MapGenerator`/planta hospitalar e pintura/mobiliário existentes, com uma variante conservada e novas texturas de NPCs; nenhum gerador ou controlador paralelo permanece em current.
- Sete pontos contextuais; E/Q, toque/click próximo e botão de interação; minimapa/indicador existentes; retorno ao campo após conversa; hipótese/histórico preservados.
- Acesso: menu > investigação hospitalar; `?investigacao=hospital`. Alternativa de leitura pelo botão no campo ou `?investigacao=hospital&leitura=1`.
- Testes de integração em `tests/27-hospital-campo.test.mjs`; relatório atualizado em docs/conferencia-relatorio-2026-10-16.md. A 2.1.1 passou 249 testes antes desta integração; o resultado da 2.2 fica no relatório.
- Backup da consolidação: archive/2026-10-16_pre-hospital-mapa.tar.gz. Abordagem de mapa paralelo descartada: archive/2026-10-16_mapa-paralelo-descartado.tar.gz. Sem publicação.

Verificação consolidada 2.2: **252/252 testes passaram**, sem falhas, em 447,4 s. Log: `docs/conferencia-2026-10-16/testes-2.2.log`. Inspeção manual: aproximação com controles originais, conversa com Helena e retorno ao mesmo mapa; captura em `docs/conferencia-2026-10-16/hospital-mesma-estrutura-pt.png`.


## 2026-10-16 · Hospital com observações e móveis próprios (2.3)

- Dois estados do modelo precisam ser registrados antes das perguntas; caderno acessível no mapa, com exportação das observações e da explicação escrita antes do retorno.
- Mural e falas retomam os registros da sessão. Móveis específicos para recepção, radiografia, sala educativa, apoio, mural e medicina nuclear, dentro do gerador/renderizador existentes.
- Detalhes e limites em [docs/hospital-2.3.md](docs/hospital-2.3.md). Não há validação de aprendizagem nem restauração da investigação após recarregar.
- Backup: `archive/2026-10-16_pre-hospital-evidencias-mobiliario.tar.gz`. Sem publicação.

Verificação 2.3: **255/255 testes passaram**, sem falhas ou testes ignorados, em 446,1 s. Log: `docs/conferencia-2026-10-16/testes-2.3.log`. Captura do mapa: `docs/conferencia-2026-10-16/hospital-mobiliario-2.3.png`.

## 2026-10-16 · Verificação final antes da publicação (2.3)
- Conferido sem alterar o jogo: sintaxe de todos os módulos, suíte completa (255 testes: 253 na rodada completa + 2 testes de documentação reexecutados com a pasta docs, que faltava na cópia de trabalho), citação AIEA SRS-13 seção 4.2 e inspeção visual do mapa em 360×640 e 640×360 (PT e EN).
- Observações visuais (não bloqueiam): no celular, o texto "Helena · recepção · E / Q" e o contador "0/7 observações" se sobrepõem no centro; o botão Correr cobre parte do rótulo "Mural"; o contador aparece também no cabeçalho.
- Pendente: teste em celular real; revisão por físico médico.

## 2026-10-16 · Ajuste de HUD do hospital no celular (2.3)
- Pedido: corrigir a sobreposição de textos apontada na verificação final.
- `styles.css`: no hospital, o contador central `#sources-tracker` fica oculto (o cabeçalho já mostra "Observações n/7"). Nada mais alterado.
- Testes executados após o ajuste: 25, 27, 28 (16/16), 15 e 16 (15/15). A suíte completa não foi repetida (mudança só de CSS escopada ao hospital).
- Limite conhecido: o botão Correr e os botões do canto podem cobrir, de passagem, rótulos do mapa; é sobreposição de controles sobre o cenário, não de textos do HUD entre si.
- Backup: `archive/2026-10-16_pre-ajuste-hud-hospital.tar.gz`. Arquivo mais antigo removido para respeitar o limite de 5 (foram apagados 5 backups de pastas antigas: pre-modo-revisao, pre-investigacao, pre-dados-insuficientes, pre-modo-professor, pre-sorteio).

## 2026-10-19 · Versão 2.4: abas Missões | Investigações e dica de localização das fontes
- Pedido (após teste no celular): (1) no celular as investigações apareciam mais em evidência que as missões; (2) fontes difíceis de achar saturam o jogador; (3) melhorar os móveis (etapa 3, ainda não iniciada no código).
- Abas "Missões | Investigações" em "Selecionar missão" (decisão minha: você não escolheu entre abas e tela com dois cartões). Missões é a aba padrão ao abrir pelo menu principal; ao sair de uma investigação volta-se à aba Investigações. Chaves i18n 192 → 198.
- Dica de localização (`js/encontros/dica.js`, valores [H]): sem progresso por 90 s, as fontes que faltam pulsam em vermelho no minimapa (grátis); aos 150 s, ou ao pedir (botão 📍 Dica / tecla H, 8 s), também no mapa, o que desconta 2 pontos do aproveitamento (uma cobrança por intervalo entre duas fontes achadas, teto de 6). "Progresso" = fonte identificada, lição concluída, chave ou Geiger pegos. Automática respeita "mostrar dicas"; o botão sempre vale. Uso aparece no resumo final. No celular o botão fica sob a pausa.
- O aviso da dica espera outra notificação (ex.: assistência do alfa) terminar.
- Versão no menu: 2.4 · 2026-10-19.
- Testes: 262/262 (novo `tests/29-dica-fontes.test.mjs`, 6 testes; ajustes em 01 e 25), rodada completa antes do ajuste de versão; teste 23 rodado de novo depois.
- Backup: `archive/2026-10-19_pre-abas-dica.tar.gz` (removido `pre-conferencia-codex`, o mais antigo). Sem publicação.

## 2026-10-19 · Ícones das blindagens (2.4)
- Pedido: os símbolos das blindagens (emojis 🚫🔩🧊🧱) não faziam sentido ("parafuso"). Uma primeira versão com placas em 3D e siglas (Al/Acr/Pb) foi rejeitada: ficou feia e com elementos químicos no botão.
- Versão atual (SVG próprio, sem texto, em `index.html` + `styles.css`): sem blindagem = placa vazia tracejada; alumínio = folha prateada ondulada com dobra no canto; acrílico = painel transparente azulado com reflexos; chumbo = barra/lingote pesado e escuro. O nome e a espessura continuam no título do botão (Alumínio 3 mm, Acrílico 5 mm, Chumbo 1 cm).
- Testes: 15, 16, 01, 06 e 29 passam (59 testes nesses arquivos). Suíte completa não repetida: só HTML/CSS dos botões mudou.
- Backup: `archive/2026-10-19_pre-icones-blindagem.tar.gz` (só index.html e styles.css; removido `pre-hospital-mapa`, o mais antigo). Sem publicação.

## 2026-10-19 · Móveis em estilo RPG, todos os temas (2.4)
- Pedido: móveis com cara de RPG de cima (Zelda/Pokémon), adequados ao tema de cada missão (aprovados os 5 pilotos).
- Diagnóstico: os móveis antigos eram desenhados com 20 px por casa em vez de 32 (ocupavam ~60% da área de colisão). Agora cada móvel ocupa toda a sua área, com contorno escuro, 3 tons por material, luz de cima-esquerda e sombra no piso.
- Arquivos novos em `current/js/render/`: `estilo-rpg.js` (cores, pincel, desgaste determinístico), `moveis-rpg.js` (despacho por `tema:id` e desgaste por tema), `moveis-rpg-interior.js` (laboratório, hospital, fábrica), `moveis-rpg-ruinas.js` (ferro-velho, usina, abrigo). `moveis.js` chama o desenho novo primeiro; os brilhos da cápsula, do reator e do RTG continuam na GameScene.
- Cobertura: 5 pilotos + 52 tipos (ids repetidos, como machine/barrel/cabinet, mudam de aparência conforme o tema). Ferramenta de revisão: `RH_ROOT=<current> node tests/ferramentas/catalogo-moveis.mjs <pasta> 2.2 [temas]` gera uma folha PNG por tema.
- Testes: suíte completa 262/262. Backup: `archive/2026-10-19_pre-moveis-rpg.tar.gz` (removido o mais antigo). Sem publicação; testar no celular real.


## 2026-10-19 · Revisão da 2.4 e plano dos próximos episódios

- Revisão sem alterar os arquivos do jogo: diferenças de fonte, cobertura do mobiliário, entrada pelas abas, hospital, modelo/caderno, viewport 360 × 640, fábrica e dica manual.
- Suíte executada novamente: **262/262 testes passaram**, sem falhas/cancelamentos/ignorados, em 447,6 s.
- Relatório com capturas, limites e proposta dos episódios de medicina nuclear, datação e radônio: [docs/revisao-2026-10-19/revisao-e-proximos-episodios.md](docs/revisao-2026-10-19/revisao-e-proximos-episodios.md).
- Principal dependência de expansão: inicialização de campo, locais e regras de UI ainda específicos do hospital. Nenhum novo episódio implementado nesta revisão. Sem publicação.

## 2026-10-19 · Botão "OK" após identificar a fonte (2.4)
- Pedido: depois de acertar a identificação, ficava só o botão "Cancelar"; o ideal é virar "OK".
- Mudança: ao acertar, o botão passa a "OK" (verde) e fecha a identificação na hora; se o jogador não clicar, o fechamento automático (8 s, ou 9 s na última fonte) continua, e os dois caminhos executam uma única vez (`fecharIdentificacao` em `GameScene.js`). Ao errar, continua "Cancelar"; ao reabrir o modal o rótulo é restaurado. Nova chave i18n `ok` (199 por idioma).
- Testes: novo teste em `02-fluxo`; suíte completa 263/263. Backup: `archive/2026-10-19_pre-botao-ok.tar.gz` (removido o mais antigo). Sem publicação.


## 2026-10-19 · Três novos episódios no mesmo framework (2.5)

- Coleção com hospital original, medicina nuclear (6 etapas), Arquivo do tempo (7) e radônio na escola (6), em PT/EN.
- Cena de campo comum herda a GameScene; configurações por episódio mantêm mapas, movimento, câmera, controles e renderização existentes. ID selecionado governa cenário, ficha e reinício.
- Atividades: aquisição/distribuição do sinal, amostras e dados U-Pb, preservação qualitativa de traços, campanha sintética de radônio e comparação de protocolos. Hipótese, observações, tentativas e explicação anterior ao retorno são exportáveis; dados insuficientes podem ser a conclusão correta.
- Sete novos tipos de mobiliário com o pincel RPG e novos perfis de NPCs fictícios.
- **273/273 testes passaram**, sem falhas/cancelamentos/ignorados, em 464,1 s. Percursos completos dos novos episódios em PT/desktop e EN/360 × 640, com exportação e reinício.
- Detalhes, dados, limites e referências: [docs/episodios-2.5/README.md](docs/episodios-2.5/README.md). Conteúdos novos 0.1-teste; revisão especializada e piloto pedagógico pendentes. Sessões ainda não restauram após recarregar.
- Prévia local sem cache: `python3 tools/preview.py --port 8770`. Backup: `archive/2026-10-19_pre-tres-investigacoes.tar.gz`. Backups anteriores mantidos; sem publicação.

## 2026-10-19 · Verificação final da 2.5 antes de publicar
- Cópia da pasta `current/` (76 arquivos, 2,2 MB, sem testes/docs/backups/arquivos `._*`), conferida na nuvem: sintaxe de todos os módulos JS ok e suíte completa **273/273** (0 falhas, 0 cancelados, 0 ignorados) no Chromium.
- Não verificado: celular real (abas, dica, ícones de blindagem, móveis, botão OK, os três novos episódios) e revisão especializada dos conteúdos 0.1-teste. Sem publicação por mim; comando entregue ao usuário.

## 2026-10-20 · Plantas próprias para as três investigações novas (2.6)
- Pedido: os mapas dos episódios novos eram cópia do hospital; cada um deve ser independente. Escola do radônio com várias salas, umas mais e outras menos ventiladas.
- Novo: `current/js/mapa/plantas-investigacao.js` (escola 36×22 com corredor central; laboratório de cronologia 34×22 com salão aberto e salas laterais, microscopia escura; serviço de medicina nuclear 28×26 em corredor vertical). `terreno.js` aceita `planta` (paleta própria, tinta por ambiente, janelas abertas/entreabertas/fechadas, grade de ventilação, quadros, cartazes, placas); `gerador.js` usa a planta; `configuracoes-campo.js` com pontos, rótulos e painéis novos. Hospital original sem alteração. Movimento, colisão, câmera e controles são os de sempre.
- Ventilação na escola é **só ambientação** (Sala A fechada e ar parado; Sala B aberta com exaustor e setas; rótulos "pouca/média/muita ventilação"). Nenhum dado numérico novo; o jogo não afirma relação causal com os dados sintéticos. Leitura por sala exigiria novos dados e validação.
- Testes: novo `31-plantas-investigacao` (plantas distintas, móveis todos colocados, pontos e ambientes alcançáveis, ventilação visual); suíte completa **276/276**. Imagens dos mapas conferidas na nuvem. Doc: `docs/plantas-investigacao.md`. Versão 2.6. Backup: `archive/2026-10-20_pre-plantas-proprias.tar.gz` (removidos os dois mais antigos; archive com 5). Sem publicação.

## 2026-10-20 — Laboratório de Cronologia com 5 laboratórios (v2.6)
- Pedido: reprojetar o mapa "Arquivo do tempo" como o Laboratório de Cronologia real, com 5 laboratórios detalhados.
- Mapa 40×24: Lab 1 polimento/corte/montagem; Lab 2 tratamento térmico (fornos); Lab 3 ataque químico (capelas, banhos, CR-39); Lab 4 fontes radioativas (cofres, U/Th, fontes experimentais); Lab 5 microscopia e contagem; corredor e recepção/laudo.
- Novo `js/render/mobiliario-cronologia.js` (desenhos esquemáticos, sem marcas nem valores). Equipamentos adicionais inspirados no site do grupo: ultrassom, lupa, forno tubular, bomba de vácuo, balança.
- Pontos de interação reposicionados; "Estação isotópica" renomeada para "Estação de dados U-Pb".
- Testes: 277/277. Backup: archive/2026-10-20_pre-laboratorio-cronologia.tar.gz (arquivo mais antigo removido).
- Pendência: o site lista outros 5 labs (inclui Instrumentação); mantida a estrutura pedida. Testar em celular real.

## 2026-10-20 — Lab 5 ampliado, vestiário/EPI e NPCs de segurança (v2.7)
- Pedido: Lab 5 com microscopia + eletrônica básica + impressão 3D; um NPC por laboratório com treino de segurança específico.
- Mapa do Arquivo do tempo agora 40×37: Lab 5 em 3 zonas (microscopia/contagem manual; eletrônica básica com banho automatizado e braço robótico; impressão 3D) e novo vestiário e EPI (armários, lava-olhos, chuveiro, extintor, primeiros socorros — proposta didática).
- 13 móveis novos em `js/render/mobiliario-cronologia.js` (esquemáticos, sem marcas nem valores).
- Novo `js/investigacao/treinamento-seguranca.js`: 7 instrutores (Bia, Otto, Nina, Davi, Léa, Teo, Íris), 4 passos + pergunta cada, PT/EN. Aviso "⚠ treino pendente" perto de equipamentos, sem bloquear. Selos em localStorage `rh_treinos_seguranca_v1`; HUD "treinos n/7".
- Textos de segurança = [H] rascunho geral, a validar (ver `docs/treinamento-seguranca.md`).
- Lab 4 mantido como estava (decisão do autor); só a redação dos docs públicos deve evitar detalhes do cofre.
- Testes: 282/282 (novos: 31 itens 4–5, 32 com 4 testes). Backup: archive/2026-10-20_pre-lab5-treinamento.tar.gz (mais antigo removido).
- Pendente: revisão dos textos de segurança; teste em celular real.

## 2026-10-20 — Aviso do treino de segurança como "guia" (v2.7)
- Pedido do autor: no jogo o treino é tratado como real; nada de "rascunho geral". Só enfatizar que é um guia.
- Novo aviso (PT/EN): "Guia de segurança do laboratório. É uma orientação geral e não substitui as normas e fichas de segurança do seu laboratório."
- Teste 32 e docs/treinamento-seguranca.md atualizados. Testes 31 e 32: 9/9. Backup: archive/2026-10-20_pre-aviso-guia.tar.gz.

## 2026-10-20 — Datação por traço de fissão (EDM) no Arquivo do tempo (v2.8)
- Pedido: ensinar todos os procedimentos (apatita + mica muscovita + nêutrons térmicos em reator de pesquisa + ataque com HF), com equação e dados fictícios declarados; Lab 2 = conjuntos de annealing (1 h, 10 h, 100 h, 1000 h) sem precisar dos outros labs.
- Episódio reescrito em 15 cenas (`js/investigacao/arquivo-tempo.js`); atividades novas em `atividades.js`/`modelos.js` (ataque, contagem, conjunto, mica, tabela, ζ, idade, annealing, comprimentos).
- Novos: `traco-fissao.js` (porte de ft_lib.py da skill; idade, χ², central, ζ, comprimentos), `dados-fissao.js` (dados fictícios; 12 grãos do exemplo da skill), `docs/traco-fissao-episodio.md`.
- 15 pontos de campo distribuídos nos 5 labs; treinos de segurança ganharam itens sobre HF, annealing prolongado e amostras vindas do reator (genéricos, sem números).
- Testes: 285/285 (novo 33; 30, 31, 32 ajustados). Backup: archive/2026-10-20_pre-fissao-v28.tar.gz (mais antigo removido).
- Pendente: revisão científica e de segurança por especialista; teste em celular real; banco de problemas aleatórios + etapas no caderno (proposta, aguarda validação do autor).

## 2026-10-20 — Laboratório de pesquisa: problemas sorteados (v2.9)
- Pedido: lista de problemas aleatórios para o laboratório de pesquisa, cada um com um subconjunto de salas, e etapas no Caderno; Lab 2 usável sozinho para conjuntos de annealing; problema 4 = datar + história térmica.
- Novo cartão "Laboratório de pesquisa" (Investigações): sortear ou escolher entre 4 problemas (datar apatita; conjunto de annealing; calibrar ζ; datar + história térmica).
- Novos: `problemas-pesquisa.js` (reaproveita as cenas do Arquivo do tempo + cenas próprias, respostas certas calculadas dos dados), `sorteio-fissao.js` (dados fictícios por semente; ζ calculado do padrão), `docs/laboratorio-pesquisa.md`. Endereço de teste: `?investigacao=pesquisa-datar&semente=3`.
- `observarAtividade(tipo, estado, dados)` aceita o conjunto de dados; novas atividades `annealing-medidas` e `zeta-verifica`; Caderno mostra etapas ○/✓ e o nº do sorteio; ficha exportada traz `sorteio`.
- Decisão a conferir: o problema de annealing inclui o Lab 3 (ataque químico revela os traços antes da medida), além dos Labs 2 e 5.
- Testes: 296/296 (novo 34; 25 ajustado para o 5º cartão). Backup: archive/2026-10-20_pre-lab-pesquisa-v29.tar.gz (mais antigo removido).
- Pendente: revisão científica dos textos novos; teste em celular real; mais problemas (ex.: radônio com CR-39) só após validação do autor.

## 2026-10-23 — Nome e inventário para registro de software
**Pedido:** decidir o nome do jogo e preparar o registro. **Decisão do Arnaldo:** manter "Radiation Hunters" (nenhuma marca igual ou parecida na WIPO Global Brand Database, consulta de 23/10/2026). Registrar o programa no INPI pela Inova; a marca fica para depois.
**Mudança:** novo `docs/inventario-autoria-registro.md` (identificação, elementos próprios, terceiros, autoria e IA, pendências). Nada em `current/` foi alterado.
**Achados:** não há imagem nem áudio de terceiros (gráficos desenhados por código, som sintetizado). Terceiros: Phaser 3.60.0 (MIT, falta o arquivo de licença em `vendor/`) e três Google Fonts.
**Complemento (23/10/2026):** incluído `current/vendor/PHASER-LICENSE.md`, cópia literal do LICENSE.md do Phaser na tag v3.60.0 (MIT, "Copyright (c) 2020 Richard Davey, Photon Storm Ltd."). O `phaser.min.js` em uso é idêntico ao do pacote oficial phaser@3.60.0 do npm (mesmo SHA-256). Para valer no site, falta publicar (`netlify deploy --dir=apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod`).

## 2026-10-26 — Zumbido de fundo nas missões de investigação
**Pedido:** investigar um ruído contínuo ("zummm") nas missões de investigação.
**Achado:** o único som contínuo do jogo é o drone ambiente de `audio.js` (`startMusic`): três ondas senoidais graves (55, 82,7 e 110,4 Hz) com filtro passa-baixa e modulação lenta, a 4% de ganho no volume de música padrão (50%). `InvestigacaoScene` herda de `GameScene`, cujo `create()` chamava `startMusic()` sempre; por isso o zumbido tocava também na leitura e no laboratório, onde não há ação que o justifique. Não ouvi o áudio (não tenho como ouvir daqui): a conclusão vem da leitura do código, a confirmar pelo Arnaldo.
**Mudança (v2.9.1):** em `GameScene.create()`, missões com `missionData.investigacao` não iniciam a música (e param qualquer drone ativo). Missões de caça de fontes não mudam. O controle de volume da música continua nas Configurações.
**Verificação:** sintaxe conferida com `node --check`; a suíte completa (296 testes) NÃO foi rodada nesta mudança. Backup: `archive/2026-10-26_pre-audio-investigacao.tar.gz` (o mais antigo foi removido, restam 5).
**Para publicar:** `netlify deploy --dir=apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod` (não executado).

## 2026-10-26 — Trilha sonora: 12 composições originais (v3.0)
**Pedido:** criar uma trilha sonora que faça sentido para cada missão (referência: Zelda, Pokémon), "para todos".
**Mudança:** o drone ambiente (causa do zumbido, entrada anterior) foi **removido**. Novo módulo `js/musica/` (`partitura.js`, `trilhas.js`, `sequenciador.js`): 12 faixas originais, uma por missão (1 a 8 caça de fontes; 9 a 12 investigações), sintetizadas em tempo real (ondas quadrada, de pulso, triangular, senoidal e percussão por ruído), 16 compassos em duas seções, repetindo em ciclo; volume equalizado entre as faixas. `audio.js` chama `startMusic(idDaMissão)`. Nas missões de acidentes reais (Goiânia, Chernobyl, Lia, Fukushima) a música é sóbria de propósito. Detalhes, tabela e como editar: `docs/trilha-sonora.md`. Nova página `current/trilhas.html` para ouvir cada faixa (precisa de servidor local: `python3 -m http.server` em `current`).
**Verificação:** teste novo `35-trilhas` (notas na escala, acordes, tessitura, 16 compassos, faixas distintas; renderização offline: sem estourar, sem silêncio, nível equalizado; integração com o jogo). **Não foi verificado se a música soa boa:** depende do ouvido do Arnaldo; o texto de cada melodia é editável.
**Pendente do autor:** (1) ouvir as 12 faixas e dizer o que mudar; (2) decidir como constar a autoria da música (composição assistida por IA) no registro de software.
**Para publicar:** `netlify deploy --dir=apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod` (não executado).

## 2026-10-26 — Música não tocou após a publicação (reforço do desbloqueio de áudio)
**Relato do Arnaldo:** "não tocou". **Investigação:** em Chromium com a política de reprodução automática estrita (`--autoplay-policy=user-gesture-required`) a trilha toca: o contexto fica `running`, o relógio avança, o ganho é 0,15 e não há erro no console. Portanto a causa NÃO está confirmada; hipóteses: (a) a publicação não terminou (o primeiro `netlify deploy` falhou por caminho relativo); (b) cache do navegador com o `audio.js` antigo; (c) Safari, que mantém o áudio suspenso até um gesto; (d) volume da música em 0 nas Configurações salvas.
**Mudança:** `audio.js` ganhou `desbloquear()`: o contexto de áudio é retomado no próximo clique, toque ou tecla (importante no Safari); se a trilha falhar, o motivo vai para o console (`Trilha sonora indisponível`). Teste 35 e verificação com política estrita passam.

## 2026-10-26 — Configurações durante a missão: música e efeitos ligáveis (v3.0.1)
**Pedido:** poder ligar e desligar música e áudio durante as missões.
**Mudança:** o menu de pausa (Esc) ganhou o botão **Configurações**, que abre a janela de configurações por cima da pausa (Esc fecha só ela). Novas chaves **Música ligada** e **Efeitos sonoros ligados**: desligar não perde o volume escolhido; os valores ficam salvos (`musicOn`, `soundOn`). Valores antigos ou inválidos voltam ao padrão (ligado). Testes: 305/305 (novos: configuração dentro da missão e persistência).
**Para publicar:** `netlify deploy --dir=/Volumes/EXBOM/LabVirtualGC/apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod` (não executado).

## 2026-10-26 — Correção: menus que não respondiam + música em todas as investigações (v3.0.2)
**Pedido:** (1) depois da última publicação, "Missões" e demais menus pararam de funcionar; (2) havia investigação sem música.
**Causa provável (hipótese, não confirmada no navegador do usuário):** `index.html` antigo em cache com `ui.js` novo → `getElementById('music-on'/'sound-on'/'btn-settings-pausa')` devolvia `null` e o `addEventListener` lançava erro durante a montagem da interface, deixando os menus sem ação. Reproduzido em teste (página antiga simulada): sem a proteção o teste falha.
**Mudança:** `ui.js` e `main.js` tolerantes a elementos ausentes (`?.` e verificações de nulo). `musica/trilhas.js`: os 4 problemas do Laboratório de pesquisa (ids 13–16) usam a trilha 11 (laboratório de cronologia); outros ids continuam sem música.
**Testes:** `tests/35-trilhas.test.mjs` (12 testes: página antiga em cache; toda investigação, 4 cartões + 4 problemas, toca trilha); `tests/helpers/navegador.mjs` ganhou a opção `transformarHtml`.
**Para publicar:** `netlify deploy --dir=/Volumes/EXBOM/LabVirtualGC/apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod` (não executado).

## 2026-10-26 — Versão visível logo abaixo do subtítulo (v3.0.2)
**Pedido:** mostrar a versão do jogo no menu, abaixo do subtítulo.
**Mudança:** o parágrafo `#versao-jogo` saiu do fim do menu e foi para logo abaixo de "The Isotope Chronicles"; `VERSAO` em `js/modo.js` estava desatualizada (2.9) e passou a `3.0.2 · 2026-10-26`. Teste: `tests/23-modo-professor.test.mjs` (a versão aparece no menu).
**Para publicar:** `netlify deploy --dir=/Volumes/EXBOM/LabVirtualGC/apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod` (não executado).

## 2026-10-26 — Escola do radônio em campus, texto do radônio revisado (v3.1.0)
**Pedido:** conferir a consistência da missão do radônio; mapas das investigações muito parecidos → mapas e móveis diferentes, ampliados; escola com áreas livres, não um prédio só.
**Texto (radônio):** nota fictícia no registro (janelas da sala A fechadas nos períodos 4 a 8, sem afirmar causa) e frase de referência da OMS (100 Bq/m³; no máximo 300 se não for possível; fonte conferida: WHO, 21/09/2009, https://www.who.int/news/item/21-09-2009-who-calls-for-tighter-standards-on-indoor-radon). Aviso "versão de teste" mantido (decisão pendente).
**Motor:** `render/terreno.js` pinta terreno aberto (grama, calçada, asfalto, terra, quadra com marcações, borda de muro ou mata); `mapa/plantas-investigacao.js` aceita `externo`, `blocos`, `internas`, `cercas`, `zonas[].piso`. Novo `render/mobiliario-externo.js`: árvore, banco, mastro, canteiro, trave, carro, bicicletário, placa.
**Escola:** campus 54×44 com prédio antigo (secretaria, salas A e B, corredor), bloco administrativo (professores, conselho), biblioteca, pavilhão de análise, pátio, estacionamento, horta e quadra; pontos de investigação reposicionados; ventilação visual preservada.
**Pendente:** hospital e medicina nuclear ainda com o desenho anterior (segunda rodada); decisão sobre "versão de teste".
**Testes:** suíte completa 309/309; `tests/31` ganhou o teste do campus (alcançabilidade de todos os tiles e pontos). Ferramenta: `tests/ferramentas/captura-mapa.mjs`. Doc: `docs/mapas-campus.md`.
**Para publicar:** `netlify deploy --dir=/Volumes/EXBOM/LabVirtualGC/apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod` (não executado).

## 2026-10-26 — Hospital e medicina nuclear em complexos próprios (v3.2.0)
**Pedido:** mapas e móveis próprios para o hospital e a medicina nuclear (as investigações pareciam iguais).
**Hospital (9):** complexo em "H" 52×40, duas alas (radiografia/laudos/recepção e educativa/apoio/mural/medicina nuclear) ligadas por saguão, dois jardins internos, baia de ambulâncias e estacionamento na frente, área de resíduos cercada com gerador. Antes: mapa gerado 24×16.
**Medicina nuclear (10):** bloco clínico (comunicação, equipe, acolhimento, conversa) e bloco técnico (radiofármacos didático, controle, aquisição) ligados por passarela; pátio de armazenamento cercado com contêineres blindados (esquemáticos), baia de embarque, jardim. Antes: um prédio com corredor.
**Móveis novos:** `ambulance`, `waste_container`, `planter`, `lamp_post`, `generator_unit`, `bus_shelter`, `lead_container`. **Correção:** `bench` → `yard_bench` e `car` → `parked_car` (ids repetiam os do ferro-velho e redesenhariam as missões 2 e 7); teste novo contra ids repetidos.
**Motor:** `cercas` agora também são paredes (muros e pátios cercados com vãos).
**Testes:** `tests/27` (mapa 52×40), `tests/31` (todas as plantas, hospital incluído, ids únicos, plantas distintas). Suíte completa 311/311.
**Pendente:** decisão sobre o aviso "versão de teste".
**Para publicar:** `netlify deploy --dir=/Volumes/EXBOM/LabVirtualGC/apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod` (não executado).

## 2026-10-27 — Celular, fundo do Geiger e ferramentas de revisão
**Pedido:** próximas etapas (decisão do fundo do Geiger; acessibilidade e celular com os mapas grandes).
**Celular:** escola, nos formatos 844×390 e 390×844, sem erros; o minimapa cobria o ponto inicial na paisagem, então `PLANTA_ESCOLA.inicio` passou de (2,19) para (5,19). Varredura de telas (menu, missões, investigações, campo, pausa e configurações; PT e EN; 360×740 e 740×360): sem rolagem horizontal, sem botões sem rótulo, sem alvos de toque pequenos.
**Fundo do Geiger:** mantido em 5 cps; experimento e motivos em `docs/geiger-projeto-3a.md` (8 testes dependem do valor; identificação usa 2× o fundo).
**Ferramentas:** `tests/ferramentas/captura-celular.mjs` e `tests/ferramentas/varredura-celular.mjs`.
**Pendente:** cofre definitivo (chat próprio com o Opus), classificação do I-131, aviso "versão de teste", revisão crítica final.
**Para publicar:** `netlify deploy --dir=/Volumes/EXBOM/LabVirtualGC/apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod` (não executado).

## 2026-10-27 — Carros mais legíveis, decisões registradas para o cofre
**Pedido:** seguir as próximas etapas.
**Mudança:** `parked_car` redesenhado (carroceria, cabine em vidro, rodas, faróis e lanternas) com cor variada por posição; `tests/ferramentas/captura-mapa.mjs` aceita um ponto (`... <zoom> <x> <y>`) para capturar perto de um lugar.
**Decisões registradas em `docs/prompt-cofre-opus.md`:** fundo do Geiger mantido em 5 cps; I-131 recomendado na prateleira gama (a validar no chat do cofre); aviso "versão de teste" mantido (aparece só no modo de revisão e é verdadeiro).
**Pendente:** cofre definitivo (chat próprio com o Opus) e, depois, a revisão crítica final.
**Para publicar:** `netlify deploy --dir=/Volumes/EXBOM/LabVirtualGC/apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod` (não executado).

## 2026-10-27 — Revisão do cofre pelo Opus (só leitura)
**Pedido:** rodar o prompt do cofre no Opus (esforço alto).
**Mudança:** `docs/prompt-cofre-opus.md` reescrito para refletir o estado real (cofre interativo já implementado em 14/10); versão antiga em `docs/_historico/prompt-cofre-opus_2026-10-14.md`. Nada alterado em `current/`, `tests/` nem `archive/`.
**Resultado:** `docs/revisao-cofre-2026-10-27/plano-opus.md` (plano por etapas; I-131 → `type` "gama" a aprovar; correções de celular no cofre; lista de candidatos sem repetição no botão de identificação; recomendação para as 6 decisões pendentes), 20 capturas + `metricas.json` em `capturas/` (feitas numa cópia na nuvem; fontes do Google não carregaram) e os scripts `captura-cofre.mjs` e `sonda-identificar.mjs`.
**Pendente:** sua aprovação do plano, sobretudo da troca do `type` do I-131.

### 2026-10-27 — Revisão do cofre (plano do Opus), etapas 0 e 1
**Pedido:** executar o plano `claude/radhunter-plano-cofre-opus-2026-10-27.md`. **Etapa 0:** backup `archive/2026-10-27_pre-cofre-opus.tar.gz` (removido o mais antigo, `2026-10-20_pre-aviso-guia`; 5 no archive).
**Etapa 1 (aprovada por Arnaldo):** I-131 `type: "gama"` (`symbol: "γ"`, `energyMeV: 0.3645`); beta vira componente secundária. Testes ajustados: 01, 04, 05, 12. Docs: `geiger-projeto-3a.md`, `cofre-5e-plano.md`, comentário em `fisica/componentes.js`. Suíte completa só ao fim das etapas 2 a 5.

## 2026-10-27 — Celular, fundo do Geiger e ferramentas de revisão
**Pedido:** próximas etapas (decisão do fundo do Geiger; acessibilidade e celular com os mapas grandes).
**Celular:** escola, nos formatos 844×390 e 390×844, sem erros; o minimapa cobria o ponto inicial na paisagem, então `PLANTA_ESCOLA.inicio` passou de (2,19) para (5,19). Varredura de telas (menu, missões, investigações, campo, pausa e configurações; PT e EN; 360×740 e 740×360): sem rolagem horizontal, sem botões sem rótulo, sem alvos de toque pequenos.
**Fundo do Geiger:** mantido em 5 cps; experimento e motivos em `docs/geiger-projeto-3a.md` (8 testes dependem do valor; identificação usa 2× o fundo).
**Ferramentas:** `tests/ferramentas/captura-celular.mjs` e `tests/ferramentas/varredura-celular.mjs`.
**Pendente:** cofre definitivo (chat próprio com o Opus), classificação do I-131, aviso "versão de teste", revisão crítica final.
**Para publicar:** `netlify deploy --dir=/Volumes/EXBOM/LabVirtualGC/apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod` (não executado).

### 2026-10-27 — Revisão do cofre, etapas 2, 3 e 5 (UX, textos, caderno)
**Etapa 2 (cofre, UX):** no celular (≤ 860 px) a ficha fecha depois de guardar ou errar, para o retorno e as prateleiras ficarem à vista; alça de fechar 96×44 px; blindagem com `role="group"` + `aria-pressed` (no lugar de `role="radio"`), opções não escolhidas apagadas e nota fixa "Escolha feita: não dá para trocar"; ficha com `position: sticky` e rolagem própria no desktop; os 5 materiais numa linha em 960×640 (a linha de blindagem ocupa a largura da prateleira); atalhos de teclado e teclas 1/2/3 só em tela sem toque, com a frase "arrastar" no toque. Achado: `.cofre-content button { font: inherit }` vence qualquer classe única de botão, por isso `.cf-mat` precisa de `.cofre-content .cf-mat` para o tamanho da fonte valer. 4 testes novos em `14`.
**Etapa 3 (textos):** papel na prateleira alfa com Am-241 ou Ra-226 ganha a frase da gama que o papel não barra (crédito do papel segue 1; HVL do chumbo calculada com `espessuraChumbo`: ≈ 0,12 mm); `beta.chumbo` liga o chumbo sozinho aos raios X de freamento e ao contêiner de chumbo de Lia (~1.300 TBq de Sr-90, já registrado em `fact5_1`; crédito segue 0,4; a frase "material leve por dentro e chumbo por fora" continua [P] e não entrou); `betaGammaHint` ganhou o teste do chumbo (o Sr-90 mantém 22% com Al e 42% com acrílico no modelo); linha "Regra de blindagem" com as citações NRC/NIST de C3.1 a C3.5 na ficha da fonte guardada (`CITACOES_REGRA` em `cofre.js`; C6.3 fora de propósito). Decisões 2 e 5 fechadas (já decididas em 14/10). Testes novos em `11` e `14`.
**Etapa 5 (caderno e contraste):** botão fechar do caderno 44×44 com nome pelo i18n (`closeNotebook`, 202 chaves por idioma); abas com `id`, `aria-controls`, `aria-label` com o nome do tema e folha com `role="tabpanel"`; cores alfa `#8a5d00` e beta `#1f63b0` na ficha (contraste 5,54 e 5,82:1 no papel); `.cf-retorno` com 64 px mínimos; baia vazia tracejada; selo "!" virou "2ª" com `title` e nome acessível ("Acerto na 2ª tentativa"). Testes em `09` e `14`.
**Estado:** testes 01, 04, 05, 09, 10, 11, 12, 13, 14 e 16 passando na cópia de trabalho; suíte completa só ao fim da etapa 4. Etapa 4 (candidatos fixos na identificação) a seguir.

### 2026-10-27 — Revisão do cofre, etapas 4 e 6 (v3.3.0)
**Etapa 4 (identificação):** lista **fixa** de candidatos por missão, sem nomes repetidos (`js/data/candidatos.js`): os isótopos distintos das fontes da missão, achadas ou não, mais `candidatosExtras` do arquivo da missão, em ordem alfabética (a posição não entrega a resposta). M2 (Cs-137): + Co-60, Sr-90, Am-241. M7 (Co-60): + Cs-137, Sr-90, Am-241. M3 (Ra-226): + Sr-90, Cs-137 (sem Am-241, porque no Geiger do jogo ele e o Ra-226 são alfa só por contato e não se distinguem por medida). O rótulo do tipo sai no idioma do jogo (EN: "α alpha"; antes "α alfa"). A missão 6 segue com os 2 reais (Co-60, Cs-137). Teste novo `36-identificacao.test.mjs` (7 testes): sem repetição, distratores presentes, par real × distrator separável por pelo menos uma placa (≥ 10 pontos percentuais) ou alfa só por contato, rótulos em EN, lista estável depois de achar uma fonte.
**Etapa 6:** `docs/roteiro-voiceover-cofre.md` (14 passos, ~15 min) para você rodar no Mac com VoiceOver + Safari; repetir os passos 1, 5, 8 e 11 no NVDA + Firefox se possível. **Não foi executado por mim: leitor de tela continua não testado.**
**Versão:** `VERSAO` passou a `3.3.0 · 2026-10-27` (aparece sob o subtítulo).
**Suíte completa na cópia de trabalho:** 329 de 329 (antes 311; +18 testes novos nas etapas 2 a 5 e 36; a conta fecha porque `01`, `04`, `05` e `12` foram só ajustados). Ainda não rodada no seu Mac (o Chromium não baixa lá).
**Não verificado:** leitor de tela; toque em aparelho real; fontes reais (Orbitron, Inter) nas capturas; Safari e Firefox.
**Pendente:** etapa 7 (revisão crítica final, chat novo em Opus, esforço alto) e a execução do roteiro de VoiceOver.
**Para publicar:** `netlify deploy --dir=/Volumes/EXBOM/LabVirtualGC/apps/radhunter/current --site=d8c7ba5a-9508-421d-b97e-50ed205c0c1f --prod` (não executado).

### 2026-10-27 — Prompt da revisão crítica final (etapa 7)
**Pedido:** preparar o prompt. **Feito:** `docs/prompt-revisao-final-opus.md` (também no Projeto, `claude/radhunter-prompt-revisao-final-opus.md`). Para colar num chat novo em Opus, esforço alto; revisão só de leitura, saída em `docs/revisao-final-2026-10-28/`.
